# Meta

This folder contains metadata files describing the packages listed in
`src/contrib`. These files support automated tools and workflows that rely on 
CRAN-like metadata formats. In this repository, this folder is intended for the
storage of validation reports, in RDS format and other files about the packages on the repository.

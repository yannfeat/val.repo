#' Tmat
#' @name Tmat
#' @docType data
NULL

#' fFrame
#' @name fFrame
#' @docType data
NULL

#' fr1
#' @name fr1
#' @docType data
NULL

#' Examples If FALSE
#'
#' @param x A parameter
#'
#' @return Some value
#' @export
#'
#' @examplesIf 2 + 2 == 5
#' examplesIf_false()
examplesIf_false <- function() {
  print("Hello, world!")
}

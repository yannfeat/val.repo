# foobar 1.1.0

* thanks @foo-bar for their contribution (#111)

* thanks @foo2- for their contribution (#11)

* thanks @JohnDoe, @JaneDoe

* this should not be linked: foo.bar@email.com

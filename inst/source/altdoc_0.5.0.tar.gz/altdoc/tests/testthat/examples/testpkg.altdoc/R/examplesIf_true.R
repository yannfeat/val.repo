#' Examples If TRUE
#'
#' @param x A parameter
#'
#' @return Some value
#' @export
#'
#' @examplesIf 2 + 2 == 4
#' examplesIf_true()
examplesIf_true <- function() {
  print("Hello, world!")
}

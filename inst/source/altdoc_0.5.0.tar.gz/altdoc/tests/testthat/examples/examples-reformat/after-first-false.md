# Package

## Installation

Well hello there

### Stable version

Here's some code:

```r
# here's a comment
1 + 1
```

### Dev version

Hello

## Demo

Hello again


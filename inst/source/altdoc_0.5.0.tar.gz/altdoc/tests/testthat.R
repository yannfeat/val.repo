library(testthat)
library(altdoc)

test_check("altdoc")

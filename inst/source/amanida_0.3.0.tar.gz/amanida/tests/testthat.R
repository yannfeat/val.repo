library(testthat)

library(amanida)

test_check("amanida")

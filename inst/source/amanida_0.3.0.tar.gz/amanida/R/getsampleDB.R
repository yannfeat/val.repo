#' Function to sample data path
#' @export

getsampleDB <- function() {system.file("extdata", "dataset2.csv", package = "amanida")}


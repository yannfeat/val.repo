reg.fun <-
function(Vec, ...)  UseMethod("reg.fun")

plot.kpmfe.fun <-
function(x,...) plot.kpmfe.fun1d (x,...)

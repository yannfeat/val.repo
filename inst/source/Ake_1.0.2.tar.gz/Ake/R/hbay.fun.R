hbay.fun <-
function(Vec, ...)  UseMethod("hbay.fun")

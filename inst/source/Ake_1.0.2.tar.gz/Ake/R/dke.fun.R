dke.fun <-
function(Vec, ...)  UseMethod("dke.fun")


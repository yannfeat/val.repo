plot.hcvd.fun <-
function(x,...) plot.hcvd.fun1d (x,...)

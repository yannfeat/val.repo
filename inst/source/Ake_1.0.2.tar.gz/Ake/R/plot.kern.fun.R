plot.kern.fun <-
function(x,...) plot.kern.fun1d (x,...)

# agua 0.1.4

* bump tune version

# agua 0.1.3

* h2o_start warnings when java is not found

* typos

# agua 0.1.2

# agua 0.1.1

* Fix CRAN warning

# agua 0.1.0

* First full-featured release

# agua 0.0.1

* Test release with basic fitting functions

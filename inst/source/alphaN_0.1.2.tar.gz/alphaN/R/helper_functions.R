# Helper functions

# Vectorizes alphaN for plotting
alphaN_vec <- Vectorize(alphaN)

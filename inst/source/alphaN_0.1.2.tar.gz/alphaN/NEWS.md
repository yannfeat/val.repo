# alphaN 0.1.2

# alphaN 0.1.1

* Removed vignette example that depended on unstable dataset.

# alphaN 0.1.0

* Added a `NEWS.md` file to track changes to the package.
* First CRAN submission.

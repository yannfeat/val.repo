# actfts 0.3.0

# actfts 0.2.0

* Initial CRAN submission.

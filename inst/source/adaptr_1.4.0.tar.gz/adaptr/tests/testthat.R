library(testthat)
library(adaptr)

test_check("adaptr")

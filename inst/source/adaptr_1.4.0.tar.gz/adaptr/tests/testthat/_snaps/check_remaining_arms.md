# check_remaining_arms works and errors correctly

    Code
      check_remaining_arms(res)
    Output
              arm_A       arm_B arm_C  n prop        se     lo_ci     hi_ci
      1                superior       13 0.65 0.1322876 0.3907211 0.9092789
      2 equivalence equivalence        3 0.15 0.2061553 0.0000000 0.5540569


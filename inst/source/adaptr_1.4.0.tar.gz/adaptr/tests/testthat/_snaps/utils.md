# stop0, warning0 and cat0 work

    error message

---

    warning message

---

    thisisatest


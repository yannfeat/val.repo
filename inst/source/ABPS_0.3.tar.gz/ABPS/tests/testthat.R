library(testthat)
library(ABPS)

test_check("ABPS")

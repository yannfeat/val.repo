#' Adverse event data set included in AdEPro
#'
#'@name adae_data
#'@keywords internal
NULL

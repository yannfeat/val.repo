## ----ex-sim, eval=FALSE-------------------------------------------------------
#  fit <- adjClust(k, type = "similarity")

## ----ex-sim2, eval=FALSE------------------------------------------------------
#  fit <- adjClust(k, type = "similarity", h = h)

## ----ex-dissim, eval=FALSE----------------------------------------------------
#  fit <- adjClust(d, type = "dissimilarity")

## ----ex-dissim-sparse, eval=FALSE---------------------------------------------
#  fit <- adjClust(d, type = "dissimilarity", h = h)


library("testthat")
library("adjclust")

test_check("adjclust")

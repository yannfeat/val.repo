library(testthat)
library(africamonitor)

test_check("africamonitor")

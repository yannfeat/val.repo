library (testthat)
library (httptest2)
library (allcontributors)

test_check ("allcontributors")

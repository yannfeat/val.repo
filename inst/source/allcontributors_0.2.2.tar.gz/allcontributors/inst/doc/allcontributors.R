## ----pkg-load, echo = FALSE, message = FALSE----------------------------------
library (allcontributors)

## ----short, eval = FALSE------------------------------------------------------
#  add_contributors (num_sectons = 1, format = "text")


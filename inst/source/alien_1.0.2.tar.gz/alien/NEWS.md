# alien 1.0.2

# alien 1.0.2

* Added more extensive documentation, including citations for the newly published Buba et al 2024.
* Added multiple ways to pass the `y` argument - either variable name, column name, or call to column within the provided data.
* Fixed bug where `~ 1` would throw an error without data.
* Added likelihood space mapping function

# alien 1.0.1

* CRAN release
* Added .github directory to .Rbuildignore to fix the note:
  Found the following hidden files and directories:
   .github
  These were most likely included in error. See section 'Package
  structure' in the 'Writing R Extensions' manual.

  CRAN-pack does not know about
   .github

# alien 1.0.0

# alien 0.0.0.9000

* Added a `NEWS.md` file to track changes to the package.

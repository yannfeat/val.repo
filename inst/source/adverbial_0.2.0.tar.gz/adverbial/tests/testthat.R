library(testthat)
library(adverbial)

test_check("adverbial")

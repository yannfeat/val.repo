#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom pillar obj_sum
#' @importFrom pillar type_sum
## usethis namespace: end
NULL

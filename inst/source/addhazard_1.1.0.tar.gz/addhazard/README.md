# addhazard

addhazard 1.1.0 updates:

1. add a two-phase sampling example dataset, nwts.2ph.rda, to the data folder
2. add R file nwts.2ph.generator.R to generate the nwts.2ph example dataset
3. update documentations
4. add rownames to the summary stat where there is only one covariate
5. clean the typo in ah.2ph() on updating wts.2ph
6. add importFrom stats model.weight to ah.R file
7. add ah.fit.R but currently surppress the use of this function. 
   It will be activated in the later version. 

list(
  rd_family_title = list(
    is = "Identifies type of Object with return of TRUE/FALSE: ",
    assertion = "Checks for valid input and returns warning or errors messages: ",
    what = "Identifies type of object and returns type: ",
    quo = "Helpers for working with Quosures: ",
    quote = "Helpers for working with Quotes and Quoting: ",
    get = "Brings something to you!?!: ",
    test_helper = "Helps with Testing: ",
    dev_utility = "Developer Utility Functions: ",
    warnings = "Function that provide users with custom warnings"
  )
)

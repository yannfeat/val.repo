# get_new_tmp_var Test 2: errors if name does not start with tmp

    Code
      get_new_tmp_var(dm, prefix = "my_var")
    Condition
      Error in `get_new_tmp_var()`:
      ! `prefix` must start with "tmp_".


# Name: ADXX
#
# Label: XXX
#
# Input: xx, xx, xx
library(admiral)
library(pharmaversesdtm) # Contains example datasets from the CDISC pilot project

# Add your template ADaM script code

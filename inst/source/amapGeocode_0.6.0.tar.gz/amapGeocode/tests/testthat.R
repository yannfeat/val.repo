library(testthat)
library(amapGeocode)

test_check("amapGeocode")

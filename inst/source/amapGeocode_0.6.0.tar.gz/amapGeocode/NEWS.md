# amapGeocode 0.6.0
* Improve the implement of parallel requests 
* Replace `parallel` with `future`

# amapGeocode 0.5.1
* Merge `to_tb` and `output` argument.

# amapGeocode 0.5.0
* Add parallel operation

# amapGeocode 0.4.0
* Return bad request as NA tibble
* Replace `tibble` by `data.table`

# amapGeocode 0.3.1
* Improve the examples of functions

# amapGeocode 0.3.0
* Added ability to batch process requests for `getAdmin()`, `getLocation()`, `getCoord()`, `convertCoord()` functions
* Tag `convertCoord()` as an Experimental function

# amapGeocode 0.2.0
* Add other three main functions: `getAdmin()`, `extractAdmin()` and `convertCoord()`

# amapGeocode 0.1.0

* First release with four functions: `getCoord()`,`extractCoord()`,`getLocation()` and `extractLocation()`

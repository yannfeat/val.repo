library(testthat)
library(ACEsearch)

test_check("ACEsearch")

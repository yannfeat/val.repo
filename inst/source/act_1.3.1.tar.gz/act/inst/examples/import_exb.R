library(act)

\dontrun{
	# To import a .TextGrid file of your choice:
	filePath <- "PATH_TO_AN_EXISTING_TEXTGRID_ON_YOUR_COMPUTER"
	
	t <- act::import_exb(filePath=filePath)
	t
}




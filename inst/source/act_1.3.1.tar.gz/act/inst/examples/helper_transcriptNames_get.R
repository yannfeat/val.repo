library(act)

act::helper_transcriptNames_get(examplecorpus)


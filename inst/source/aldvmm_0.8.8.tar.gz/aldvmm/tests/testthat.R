library(testthat)
library(aldvmm)

test_check("aldvmm")

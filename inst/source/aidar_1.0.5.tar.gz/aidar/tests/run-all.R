library(testthat)
test_check("aidar")

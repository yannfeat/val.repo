library(testthat)
library(AeRobiology)

test_check("AeRobiology")

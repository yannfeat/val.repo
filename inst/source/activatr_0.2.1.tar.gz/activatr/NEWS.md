# activatr 0.2.1

## Other Improvements

* Remove `lintr` and `styler` as dependencies (#17).

# activatr 0.2.0

## Breaking Changes

* Require R 4.1, and use native pipe rather than `magrittr`.

## Other Improvements

* Use `slider::slide_index_mean` rather than `slider::slide_index_dbl`.
* Update documentation as part of `pkgdown` site creation.
* Fix incorrect documentation of package (#14).

# activatr 0.1.1

* Switch dependency from `timetk` to `slider` to avoid unnecessary indirection (#3).

# activatr 0.1.0

* Initial release.

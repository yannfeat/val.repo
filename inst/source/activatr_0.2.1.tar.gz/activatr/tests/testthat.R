library(testthat)
library(activatr)

test_check("activatr")

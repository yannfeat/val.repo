.onAttach <- function(libname, pkgname) {
  packageStartupMessage("##")
  packageStartupMessage("## This R package was supported by project PID2021-124030NB-C33")
  packageStartupMessage("## that is funded by MCIN/AEI/10.13039/ 501100011033/")
  packageStartupMessage("## and by 'ERDF A way of making Europe'/EU")
  packageStartupMessage("##")
}

## ----message=FALSE, warning=FALSE---------------------------------------------
library(agriwater)
library(terra)


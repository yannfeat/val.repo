
[![CRAN\_Status\_Badge](https://www.r-pkg.org/badges/version/sidrar)](https://CRAN.R-project.org/package=agriwater) [![CRAC\_Downloads](https://cranlogs.r-pkg.org/badges/grand-total/agriwater)](https://CRAN.R-project.org/package=agriwater)



# agriwater
an R package for spatial modeling of energy balance and actual evapotranspiration using satellite images and agrometeorological data.

#' @references <https://github.com/Auburn/FastNoiseLite>
#'
'_PACKAGE'

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @useDynLib ambient, .registration = TRUE
#' @import rlang
## usethis namespace: end
NULL

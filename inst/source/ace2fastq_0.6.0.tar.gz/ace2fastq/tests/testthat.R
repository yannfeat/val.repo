library(testthat)
library(ace2fastq)

test_check("ace2fastq")

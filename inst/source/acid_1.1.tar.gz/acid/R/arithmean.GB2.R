arithmean.GB2 <-
function(b,a,p,q){
  meanGB2 <- km.GB2(b,a,p,q,k=1)
  return(meanGB2)
}

# To Do list

## `fp_add_*` and `fp_augment_*`

Properly deal with `factor`s


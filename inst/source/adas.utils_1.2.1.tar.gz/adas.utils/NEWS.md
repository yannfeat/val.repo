# adas.utils 1.2.1

Fixed errors in fp_augment_* functions when using `rep` argument and with scaled factors.

# adas.utils 1.2.0

* Added `expand.formula`

# adas.utils 1.1.4

* `fp_augment_*` functions now update scaled units

# adas.utils 1.1.3

* Added `battery` and `cotton` data frames

# adas.utils 1.1.2

* Improved how ggTukey deals with `conf.level` argument

# adas.utils 1.1.1

* Added missing red line at 0 on ggTukey plot when working on split data.

# adas.utils 1.1.0

* Added `ggTukey` functions for plotting Tukey's HSD tests via GGPlot2.

# adas.utils 1.0.0

* Initial CRAN submission.

## Asymmetric 14C errors (van der Plicht and Hogg 2006)
F14C_to_BP14C(0.0052, 0.0006, asym = TRUE)

## Symmetric 14C errors (Bronk Ramsey 2008)
F14C_to_BP14C(0.0052, 0.0006, asym = FALSE)

library(testthat)
library(actogrammr)

test_check("actogrammr")

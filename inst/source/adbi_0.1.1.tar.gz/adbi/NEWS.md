# adbi 0.1.1 (2024-01-25)

- Update for adbcdrivermanager 0.9.0.1

# adbi 0.1.0 (2023-12-21)

- Update for DBI 1.2.0
- Adds arrow API extension

# adbi 0.0.2 (2023-12-08)

- Initial CRAN release

# adbi 0.0.1 (2023-12-07)

- Target DBI 1.1.3

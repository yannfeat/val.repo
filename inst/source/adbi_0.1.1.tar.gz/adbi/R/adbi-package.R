#' @keywords internal
#' @aliases adbi-package
"_PACKAGE"

## usethis namespace: start
#' @import DBI
#' @import methods
#' @importFrom adbcdrivermanager adbc_driver
## usethis namespace: end
NULL

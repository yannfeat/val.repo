# aimPlot
Create a pie like plot to show completeness of various aims in a project

## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## ----setup--------------------------------------------------------------------
#  library(agena.ai)

## -----------------------------------------------------------------------------
#  #setwd("/Users/user/repos/api-r")

## -----------------------------------------------------------------------------
#  local_api_clone()
#  local_api_compile()
#  local_api_activate_license("1234-ABCD-5678-EFGH")


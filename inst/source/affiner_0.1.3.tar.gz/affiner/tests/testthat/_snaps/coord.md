# print.Coord1D()

    Code
      print(p1)
    Output
      <Coord1D[3]>
           x w
      [1,] 2 1
      [2,] 5 1
      [3,] 7 1

---

    Code
      print(as_coord1d(numeric(0)))
    Output
      <Coord1D[0]>

# print.Coord2D()

    Code
      print(p1)
    Output
      <Coord2D[3]>
           x y w
      [1,] 2 3 1
      [2,] 5 4 1
      [3,] 7 6 1

---

    Code
      print(as_coord2d(numeric(0)))
    Output
      <Coord2D[0]>

# print.Coord3D()

    Code
      print(p1)
    Output
      <Coord3D[3]>
           x y z w
      [1,] 2 3 0 1
      [2,] 5 4 0 1
      [3,] 7 6 0 1

---

    Code
      print(as_coord3d(numeric(0)))
    Output
      <Coord3D[0]>


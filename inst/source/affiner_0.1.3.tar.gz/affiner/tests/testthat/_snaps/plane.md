# as_plane3d()

    Code
      print(p1)
    Output
      <Plane3D[1]>
           a b c d
      [1,] 1 2 3 4


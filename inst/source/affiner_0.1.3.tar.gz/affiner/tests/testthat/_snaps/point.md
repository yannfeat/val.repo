# as_point1d()

    Code
      print(p1)
    Output
      <Point1D[3]>
           a  b
      [1,] 1 -2
      [2,] 1 -5
      [3,] 1 -7


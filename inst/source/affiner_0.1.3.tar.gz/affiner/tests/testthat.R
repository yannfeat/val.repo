library(testthat)
library(affiner)

test_check("affiner")

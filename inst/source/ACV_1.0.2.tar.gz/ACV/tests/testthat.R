library(testthat)
library(ACV)

test_check("ACV")

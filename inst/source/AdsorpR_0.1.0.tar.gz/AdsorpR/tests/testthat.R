library(testthat)
library(AdsorpR)
test_check("AdsorpR")
UMPUniform <-
function(theta0,n,alpha)  return(theta0*(1-alpha)^{1/n})

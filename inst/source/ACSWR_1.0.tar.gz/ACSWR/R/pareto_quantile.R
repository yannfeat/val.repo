pareto_quantile <-
function(p,scale,shape) scale/(1-p)^{1/shape}

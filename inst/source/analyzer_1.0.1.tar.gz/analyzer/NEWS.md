# analyzer 1.0.0

Initial first release of analyzer

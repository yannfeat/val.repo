# ABHgenotypeR V1.0.1
 fixed a bug were plot functions would sort markers wrongly

# ABHgenotypeR V1.0.0
Release version

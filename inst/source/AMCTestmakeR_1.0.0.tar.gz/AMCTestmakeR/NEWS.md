# AMCTestmakeR 1.0.0

* Fixed bugs that resulted in compilation issues in AMC.

# AMCTestmakeR 0.1.0

* Initial release.

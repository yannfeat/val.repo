# 1.2
- `future` and `future.apply` dependencies were removed
    - `nthreads` argument is removed from `calculate_modis_par()` and `calculate_nlcd()`
- `calculate_modis_par()` is renamed to `calculate_modis()`

# 1.1
- `calc_*()` functions are renamed to `calculate_*()` per naming convention of other function family in the package

# 1.0
- First CRAN release (v.1.0.0)
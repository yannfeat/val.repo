# Run a simple experiment using  'ABD_test_data'

ABDfun(ABD_test_data1, '1010', nTree = 3)

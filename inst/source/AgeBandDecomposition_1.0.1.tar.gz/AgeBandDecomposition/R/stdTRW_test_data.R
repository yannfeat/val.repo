#' @title stdTRW test data
#'
#' @description
#' A list of two test datasets derived from TRW_readExcel function. The first list-object
#' is a `tibble` that can be used as the argument of `stdTRW` function.
#'
#' @format A list of two tibbles
#'
"inTRW"

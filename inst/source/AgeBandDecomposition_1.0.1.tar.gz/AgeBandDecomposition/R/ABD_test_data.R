#' @title AgeBandDecomposition test data
#'
#' @description
#'  A tiny test dataset including example,
#'  the basic reference for AgeBandDecomposition package.
#'
#' @format A tibble with 85 rows and 16 variables, as derived from the Excel file.
#'
"ABD_test_data1"

# affinity 0.25

* CRAN fixes. 

* First release. 

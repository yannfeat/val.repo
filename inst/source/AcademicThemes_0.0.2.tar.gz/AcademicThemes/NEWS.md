# AcademicThemes 0.0.1

* Created `AcademicThemes`.
* Added basic colour palette functions.
* Added institution themes.
* Added `ggplot2` layer functions.
* Added README.
* Built `pkgdown` site.
* Added a `NEWS.md` file to track changes to the package.

# AcademicThemes 0.0.2

* Added new colour themes
* Updated the tests

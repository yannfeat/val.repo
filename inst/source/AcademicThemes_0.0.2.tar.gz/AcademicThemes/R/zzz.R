.onAttach <- function(libname, pkgname) {
  packageStartupMessage(
    "==AcademicThemes================================\n",
    "Please be mindful of the effects of your choice\n",
    "of colour palette on people who are colour blind\n",
    "================================================"
  )
}

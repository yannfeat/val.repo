#' @keywords internal
#' @aliases aeddo-package
"_PACKAGE"

## usethis namespace: start
#' @importFrom lifecycle deprecated
#' @importFrom tibble tibble
## usethis namespace: end
NULL

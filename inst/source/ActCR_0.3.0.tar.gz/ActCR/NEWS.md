# ActCR

10 May 2022

#Extended cosinor model now is able to handel data with NA.

#Added new features for cosinor and extended cosinor model to export original and fitted time series.

#Added M10 and L5 as output for the RA function.


28 Jan 2021

#Added new functions to derive metrics from extended cosinor models.





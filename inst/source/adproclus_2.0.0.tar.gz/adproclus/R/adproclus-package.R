#' @keywords internal
#' @aliases NULL adproclus-package
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL

#ifndef ALMANAC_STEP_H
#define ALMANAC_STEP_H

#include "r.h"

sexp alma_step_impl(sexp x, sexp n, sexp events, r_ssize size);

#endif

#ifndef ALMANAC_MONTHS_H
#define ALMANAC_MONTHS_H

#include "r.h"

sexp test_month_from_days(sexp x);
const unsigned month_from_days(double x);

#endif

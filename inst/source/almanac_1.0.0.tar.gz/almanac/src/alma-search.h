#ifndef ALMANAC_SEARCH_H
#define ALMANAC_SEARCH_H

#include "r.h"

sexp alma_search_impl(sexp events, double from, double to, bool inclusive);

#endif

#ifndef ALMANAC_INITIALIZE_H
#define ALMANAC_INITIALIZE_H

#include "r.h"

// -----------------------------------------------------------------------------

sexp almanac_init();

// -----------------------------------------------------------------------------

#endif

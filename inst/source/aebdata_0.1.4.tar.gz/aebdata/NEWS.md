# aebdata 0.1.4

* Minor fixes.

# aebdata 0.1.3

* Minor fixes.

# aebdata 0.1.2

* Minor fixes.

# aebdata 0.1.1

* Minor fixes.

# aebdata 0.1.0

* Initial CRAN submission.

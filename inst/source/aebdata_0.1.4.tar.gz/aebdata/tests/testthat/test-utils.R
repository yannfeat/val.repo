test_that("connection works", {
  expect_true(test_connection_aeb())
})

library(testthat)
library(amp)

test_check("amp")

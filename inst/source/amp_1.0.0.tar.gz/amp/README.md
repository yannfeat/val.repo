# A Multivariate Point-Null Test

This is a package that implements a multivariate point null test described in [A general adaptive framework for multivariate point null testing](https://arxiv.org/abs/2203.01897).

<!-- badges: start -->
[![R-CMD-check](https://github.com/adam-s-elder/amp/workflows/R-CMD-check/badge.svg)](https://github.com/adam-s-elder/amp/actions)
<!-- badges: end -->

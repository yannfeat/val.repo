# SPDX-FileCopyrightText: 2024 Petros Koutsolampros
#
# SPDX-License-Identifier: GPL-3.0-only

#' @useDynLib alcyon
#' @importFrom Rcpp getRcppVersion
NULL

# required in testthat
#' @importFrom sf st_read
NULL

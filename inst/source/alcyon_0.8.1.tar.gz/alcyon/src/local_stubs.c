// SPDX-FileCopyrightText: 2024 Petros Koutsolampros
//
// SPDX-License-Identifier: GPL-3.0-only

/* use same define in package's own header file */
#define SP_XPORT(x) alcyon_ ## x
#include "sp_xports.c"

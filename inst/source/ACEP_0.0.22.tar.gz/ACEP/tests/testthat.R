library(testthat)
library(ACEP)

test_check("ACEP")

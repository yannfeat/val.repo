# ACEP 0.0.2.9000 (versión en desarrollo)

* Se agregaron nuevas funciones para limpieza de texto, tokenización y deteccion de menciones.

# ACEP 0.0.2

* Se agregaron nuevas funciones para limpieza de texto, tokenización y deteccion de menciones.

# ACEP 0.0.1.9000 (versión en desarrollo)

* se agregaron nuevas funciones.
* se agregaron nuevas bases de datos.
* se agregaron nuevas descripciones.
* se agregaron nuevos ejemplos.

# ACEP 0.0.1

* Se ha añadido un archivo `NEWS.md` para seguir los cambios en el paquete.

library(testthat)
library(alternativeROC)

test_check("alternativeROC")

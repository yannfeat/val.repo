# actuaryr 1.1.1

- aligned compare() to tibbles
- added functions for interest rates curve

# actuaryr 1.1.0

- three new date reference functions: dref_mtd(), dref_qtd() and dref_ytd()
- added the compare() function that compares two tables

# actuaryr 1.0.0

- added date reference functions
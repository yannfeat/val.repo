library(testthat)
library(actuaryr)

test_check("actuaryr")

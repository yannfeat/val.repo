library(testthat)
library(ACWR)

test_check("ACWR")

utils::globalVariables(c("element", "value", "three_point_upper", "three_point_lower", "three_point_best",
                         "user_name", "agg_var", "paper_id", "AUC", "Brier_Score", "agg_sum", "agg_weight", "aggregate_diff",
                         "aggregated_judgement", "asym", "avdist", "avdist_preimage", "cl", "claim_count", "cs", "d",
                         "d_max", "data", "diff_best", "diff_dist", "diff_lower", "diff_upper", "diff_width",
                         "dist_1", "dist_2", "element", "gran_binary", "indiv", "indiv_weight", "int_agg",
                         "int_weight", "log_odds", "max_agg", "mean_judgement", "median_best", "method", "n",
                         "n_experts", "no_reason_scores_for_claim", "no_weights_for_claim", "outcome",
                         "paper_id", "probit", "reason_count", "replicated_outcome", "rgamma", "rnorm", "round_1",
                         "round_2", "sd", "stat", "three_point_best", "three_point_lower", "three_point_upper",
                         "timestamp", "ub", "ul", "user_name", "vals", "value", "var.names", "var.names2", "weight",
                         "weight_obs", "width", "x", "."))





library(testthat)
library(pointblank)

test_check("aggreCAT")

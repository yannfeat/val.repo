## alfr 1.2.1

* Remove unnecessary sysdata.rda to remove warnings reported by CRAN [here](https://CRAN.R-project.org/web/checks/check_results_alfr.html)

## alfr 1.2.0

* Added folder and document delete
* Added session invalidate
* Added session is valid check
* Use pkgdown to generate package site documentation
* Improved examples
* Unit test refactor
   - tests atomic
   - mocked API easy to refresh
   - coverage > 90%

## alfr 1.1.0

* Improved documentation

## alfr 1.0.0

* Establish connection to Alfresco server
* Node retrieval and creation.
* Content upload.
* Content download.

library(testthat)
library(alfr)

test_check("alfr")

testthat::test_check(Sys.getenv('_R_CHECK_PACKAGE_NAME_'))

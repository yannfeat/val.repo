.onAttach = function (lib, pkg) {
  hook_data_table()
}

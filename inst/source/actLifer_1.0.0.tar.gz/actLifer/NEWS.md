# actLifer 1.0.0

# act_lifer 0.0.0.9000

* Added a `NEWS.md` file to track changes to the package.

*  11/14/2023: Changed package name to actLifer from lifetables to avoid conflicting package names

utils::globalVariables(c("CentralDeathRate", "ConditionalProbDeath", "ConditionalProbLife", "NumberToSurvive", "PropToSurvive", "PersonYears", "TotalYears", "LifeExpectancy", "."))


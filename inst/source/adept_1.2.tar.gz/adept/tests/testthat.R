library(testthat)
library(adept)

test_check("adept")

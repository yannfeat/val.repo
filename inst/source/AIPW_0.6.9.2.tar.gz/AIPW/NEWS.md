# AIPW 0.6.9.1

## New Features
### Repeated Cross-fitting

## Improvements and Bug Fixes
### Continuous Outcome Support Improvements
### Documentation Improvements

## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## -----------------------------------------------------------------------------
library(ALUES)
BANANATerrain

## ---- out.width="100%", echo=FALSE--------------------------------------------
knitr::include_graphics("../vignettes/img/trimf.jpg")

## ---- out.width="100%", echo=FALSE--------------------------------------------
knitr::include_graphics("../vignettes/img/tramf.jpg")

## ---- out.width="100%", echo=FALSE--------------------------------------------
knitr::include_graphics("../vignettes/img/gaumf.jpg")


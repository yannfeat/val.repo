library(testthat)
library(ALUES)

test_check("ALUES")

# afmToolkit
An R package for AFM Force-distance curves analysis.

library(testthat)
library(agvgd)

test_check("agvgd")

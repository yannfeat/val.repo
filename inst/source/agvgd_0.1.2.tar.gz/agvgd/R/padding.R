number_width <- function(numbers) {

  nchar(as.character(max(numbers)))
}

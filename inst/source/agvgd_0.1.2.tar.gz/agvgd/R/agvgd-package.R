#' @keywords internal
#' @aliases agvgd-package
"_PACKAGE"

## usethis namespace: start
#' @importFrom tibble tibble
## usethis namespace: end
NULL

#' @export
as.matrix.align_mat <- function(x, ...) {
  remove_align_mat_class(x)
}

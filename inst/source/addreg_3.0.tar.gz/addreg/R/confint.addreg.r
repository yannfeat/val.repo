confint.addreg <- function(object, parm, level = 0.95, ...) {
  confint.default(object, parm, level, ...)
}
# angstromATE 0.1.3

* add additional fields to ATE.complete()

# angstromATE 0.1.2

* initial CRAN submission
* add examples to all functions

# angstromATE 0.1.1

* Fix loading some CSV files

# angstromATE 0.1.0

* Add Status XML reader

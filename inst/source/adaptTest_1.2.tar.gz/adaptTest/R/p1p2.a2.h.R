`p1p2.a2.h` <-
function (p1,p2)    C.a2.h(p1p2.c.h(p1,p2))


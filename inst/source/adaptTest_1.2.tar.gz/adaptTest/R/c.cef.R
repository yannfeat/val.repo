`C.cef` <-
function (typ,c)        switch (typ, b = C.cef.b(c),           l = C.cef.l(c),           v = C.cef.v(c),           h = C.cef.h(c)           )


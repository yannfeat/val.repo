`p1p2.cef.v` <-
function (p1,p2)    C.cef.v(p1p2.c.v(p1,p2))


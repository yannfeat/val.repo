`p1p2.c` <-
function (typ,p1,p2)    switch (typ, b = p1p2.c.b(p1,p2),      l = p1p2.c.l(p1,p2),      v = p1p2.c.v(p1,p2),      h = p1p2.c.h(p1,p2)      )


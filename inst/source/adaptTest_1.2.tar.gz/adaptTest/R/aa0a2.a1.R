`aa0a2.a1` <-
function (typ,a,a0,a2)  switch (typ, b = aa0a2.a1.b(a,a0,a2),  l = aa0a2.a1.l(a,a0,a2),  v = aa0a2.a1.v(a,a0,a2),  h = aa0a2.a1.h(a,a0,a2)  )


`p1p2.a2` <-
function (typ,p1,p2)    switch (typ, b = p1p2.a2.b(p1,p2),     l = p1p2.a2.l(p1,p2),     v = p1p2.a2.v(p1,p2),     h = p1p2.a2.h(p1,p2)     )


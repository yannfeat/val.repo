`a0a1a2.a` <-
function (typ,a0,a1,a2) switch (typ, b = a0a1a2.a.b(a0,a1,a2), l = a0a1a2.a.l(a0,a1,a2), v = a0a1a2.a.v(a0,a1,a2), h = a0a1a2.a.h(a0,a1,a2) )


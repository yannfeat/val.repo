`a2.cef` <-
function (typ,a2)       switch (typ, b = a2.cef.b(a2),         l = a2.cef.l(a2),         v = a2.cef.v(a2),         h = a2.cef.h(a2)         )


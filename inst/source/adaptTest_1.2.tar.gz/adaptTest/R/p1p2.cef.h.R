`p1p2.cef.h` <-
function (p1,p2)    C.cef.h(p1p2.c.h(p1,p2))


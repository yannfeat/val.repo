`p1p2.a2.b` <-
function (p1,p2)    C.a2.b(p1p2.c.b(p1,p2))


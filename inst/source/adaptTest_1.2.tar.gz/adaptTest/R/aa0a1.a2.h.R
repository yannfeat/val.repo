`aa0a1.a2.h` <-
function (a,a0,a1)  ifelse(!(le(0,a1) && le(a1,a) && le(a,a0) && le(a0,1)),              NA, ifelse(eq(a0,a1),  1, (a-a1)/(a0-a1)))


`p1p2.cef` <-
function (typ,p1,p2)    switch (typ, b = p1p2.cef.b(p1,p2),    l = p1p2.cef.l(p1,p2),    v = p1p2.cef.v(p1,p2),    h = p1p2.cef.h(p1,p2)    )


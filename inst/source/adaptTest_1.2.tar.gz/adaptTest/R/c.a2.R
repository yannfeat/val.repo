`C.a2` <-
function (typ,c)        switch (typ, b = C.a2.b(c),            l = C.a2.l(c),            v = C.a2.v(c),            h = C.a2.h(c)            )


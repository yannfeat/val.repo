#' @param opportunity A string. The name of the column in `land_use_data`
#'   with the number of opportunities/resources/services to be considered when
#'   calculating accessibility levels.

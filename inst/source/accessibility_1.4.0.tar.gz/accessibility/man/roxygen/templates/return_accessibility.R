#' @return A data frame containing the accessibility estimates for each
#'   origin/destination (depending if `active` is `TRUE` or `FALSE`) in the
#'   travel matrix.

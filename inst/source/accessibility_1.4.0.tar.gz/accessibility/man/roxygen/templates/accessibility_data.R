#' @param accessibility_data A data frame. The accessibility levels whose
#'   inequality should be calculated. Must contain the columns `id` and any
#'   others specified in `opportunity`.

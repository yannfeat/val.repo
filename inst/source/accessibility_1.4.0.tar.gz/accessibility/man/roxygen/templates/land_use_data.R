#' @param land_use_data A data frame. The distribution of opportunities within
#'   the study area cells. Must contain the columns `id` and any others
#'   specified in `opportunity`.

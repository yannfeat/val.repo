#' @return A data frame containing the inequality estimates for the study area.

#' @param demand A string. The name of the column in `land_use_data` with the
#'   number of people in each origin that will be considered potential
#'   competitors.

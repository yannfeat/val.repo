#' @description This function is generic over any kind of numeric travel cost,
#' such as distance, time and money.


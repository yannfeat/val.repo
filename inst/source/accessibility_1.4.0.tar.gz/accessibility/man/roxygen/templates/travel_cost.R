#' @param travel_cost A string. The name of the column in `travel_matrix`
#'   with the travel cost between origins and destinations.

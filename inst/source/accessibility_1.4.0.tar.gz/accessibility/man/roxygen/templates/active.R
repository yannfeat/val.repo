#' @param active A logical. Whether to calculate active accessibility (the
#'   of opportunities that can be reached from a given origin, the default) or
#'   passive accessibility (by how many people each destination can be reached).

#' @return A `function` that takes a generic travel cost vector (`numeric`) as
#'   an input and returns a `list` of weight vectors (a list of `numeric`
#'   vectors, named after the arguments passed to the decay function).

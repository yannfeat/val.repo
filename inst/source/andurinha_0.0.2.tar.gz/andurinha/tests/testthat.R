library(testthat)
library(andurinha)

test_check("andurinha")

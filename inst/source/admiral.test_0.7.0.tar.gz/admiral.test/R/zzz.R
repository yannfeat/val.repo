.onAttach <- function(libname, pkgname) {
  packageStartupMessage(
    "admiral.test v0.7.0 ",
    "will be the final version. ",
    "At the end of 2023, ",
    "the package will be archived in favor of pharmaversesdtm."
  )
}

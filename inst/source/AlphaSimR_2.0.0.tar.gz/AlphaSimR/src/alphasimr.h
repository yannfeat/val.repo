#ifndef ALPHASIMR_H
#define ALPHASIMR_H

#include <RcppArmadillo.h>
#include <bitset>
#include "getGeno.h"
#include "optimize.h"
#include "misc.h"
#ifdef _OPENMP
#include <omp.h>
#endif

#endif

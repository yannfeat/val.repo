#' airqualityES: Air Quality Measurements in Spain
#'
#' aiqualityES dataset contains daily quality air measurements from 2001 to 2018.
#'
#' @author Jose V. Die \email{jose.die@uco.es}, Jose R. Caro
#'
#' @docType package
#'
#' @name airqualityES
#'
"_PACKAGE"

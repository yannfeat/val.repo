# print.adjustedcif.method

           time       cif group
    2  1.161976 0.0000000     1
    4  1.700000 0.1058201     1
    6  1.014822 0.0000000     0
    8  1.291780 0.1428571     0
    10 1.700000 0.3333333     0

# summary.adjustedcif.method

          time            cif         group
     Min.   :1.015   Min.   :0.0000   0:3  
     1st Qu.:1.162   1st Qu.:0.0000   1:2  
     Median :1.292   Median :0.1058        
     Mean   :1.374   Mean   :0.1164        
     3rd Qu.:1.700   3rd Qu.:0.1429        
     Max.   :1.700   Max.   :0.3333        


# print.curve_test, default

    ------------------------------------------------------------------
       Test of the Difference between two Survival Curves
    ------------------------------------------------------------------
    
    Using the interval: 0 to 0.2 
    
                ABC ABC SE 95% CI (lower) 95% CI (upper) P-Value N Boot
    0 vs. 1 -0.0117 0.0196        -0.0232         0.0032       1      2
    ------------------------------------------------------------------

# summary.curve_test, default

    ------------------------------------------------------------------
       Test of the Difference between two Survival Curves
    ------------------------------------------------------------------
    
    Using the interval: 0 to 0.2 
    
                ABC ABC SE 95% CI (lower) 95% CI (upper) P-Value N Boot
    0 vs. 1 -0.0117 0.0196        -0.0232         0.0032       1      2
    ------------------------------------------------------------------


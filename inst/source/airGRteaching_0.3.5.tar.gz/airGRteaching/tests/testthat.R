library(testthat)
library(airGRteaching)


test_check("airGRteaching")

#' @useDynLib AllelicSeries, .registration = TRUE
#' @importFrom Rcpp sourceCpp
NULL


#' @keywords internal
"_PACKAGE"


## usethis namespace: start
## usethis namespace: end
NULL

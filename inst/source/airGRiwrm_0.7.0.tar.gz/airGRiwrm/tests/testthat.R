library(testthat)
library(airGRiwrm)

test_check("airGRiwrm")

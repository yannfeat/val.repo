# abdiv 0.2.0

* First CRAN release.
* Added many new functions.
* Documented and tested everything.
* Wrote a long README.

Notes on correspondence between this implementation and other software can be
found in comments at the bottom of R/alpha.R and R/beta.R.

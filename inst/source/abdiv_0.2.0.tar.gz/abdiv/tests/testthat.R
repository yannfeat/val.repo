library(testthat)
library(abdiv)

test_check("abdiv")

#' @export
format.altair.vegalite.v2.api.TopLevelMixin <- function(x, ...){
  utils::str(x)
}

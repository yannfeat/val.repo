library(testthat)
library(admixr)

test_check("admixr")

library(testthat)
library(adfExplorer) |> suppressMessages()

test_check("adfExplorer")
closeAllConnections()
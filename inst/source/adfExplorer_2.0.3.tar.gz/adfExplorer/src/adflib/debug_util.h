
#ifndef __ADFLIB_DEBUG_UTIL__
#define __ADFLIB_DEBUG_UTIL__

#ifdef __cplusplus
extern "C" {
#endif

void adfPrintBacktrace ( void );

#ifdef __cplusplus
}
#endif

#endif

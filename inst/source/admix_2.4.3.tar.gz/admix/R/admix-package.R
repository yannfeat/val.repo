#' @keywords internal
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @useDynLib admix, .registration = TRUE
#' @importFrom Rcpp sourceCpp
#' @importFrom utils packageVersion
#' @importFrom Rdpack reprompt
## usethis namespace: end
NULL

#' This code was written by Alice Cleynen, Guillem Rigaill, and Michel Koskas
#' as part of the Segmentor3IsBack package, which is no longer in CRAN. It has
#' been imported into the ActiSleep package to ensure this package's longevity.
#'
#' @noRd
#'
.onAttach <- function(lib, pkg) {
    packageStartupMessage("Segmentor3IsBack v2.0 Loaded \n")
}



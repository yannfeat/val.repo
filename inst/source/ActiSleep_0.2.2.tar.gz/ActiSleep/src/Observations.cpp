/*
 *  Observations.cpp
 *  Segments
 *
 *  Created by Michel Koskas on 10/01/11.
 *  Copyright 2011 INRA, INA. All rights reserved.
 *
 */

#include "Observations.h"


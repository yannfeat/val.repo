/*
 *  Sets.cpp
 *  Segments
 *
 *  Created by Michel Koskas on 13/01/11.
 *  Copyright 2011 INRA, INA. All rights reserved.
 *
 */

#include "Sets.h"





AtomicSet::~AtomicSet()
{
}

AtomicSet::AtomicSet()
{
}



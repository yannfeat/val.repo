/*
 *  Segmentor.cpp
 *  Segments
 *
 *  Created by Michel Koskas on 06/01/11.
 *  Copyright 2011 INRA, INA. All rights reserved.
 *
 */

#include "Segmentor.h"
#include "Function.h"
#include "Sets.h"
#include "Constants.h"


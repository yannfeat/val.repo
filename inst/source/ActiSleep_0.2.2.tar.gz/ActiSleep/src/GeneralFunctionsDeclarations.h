#include <iostream>

#include "Sets.h"
#include "Segment.h"
#include "Segmentor.h"
#include "Function.h"
#include "Observations.h"
#include "Poisson.h"
#include "Exp.h"
#include "Trinome.h"




library("testthat")
library("acnr")

test_check("acnr")

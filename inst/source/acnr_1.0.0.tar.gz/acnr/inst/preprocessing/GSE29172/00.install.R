if (!require("aroma.affymetrix", quietly=TRUE)) {
    source("http://aroma-project.org/hbLite.R");
    hbInstall("aroma.affymetrix");
    ## hbInstall("aroma.cn");
}


library(testthat)
library(amelie)

test_check("amelie")

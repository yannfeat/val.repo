# amelie 0.2.1

* Added RNG hotfix as per CRAN instructions, for the upcoming R 3.6 change.

# amelie 0.2.0

* Added multivariate option for probability density function calculation.
* Added Matthews correlation coefficient as score for epsilon optimization.
* Added pdfunc for computing density separately.
* Added steps argument to ad function.
* Added multivariate section to introduction vignette.
* Added a `NEWS.md` file.

# amelie 0.1.0

* Initial release supporting the univariate Gaussian approach with F1 score.
# aceEditor 1.0.1

Compliance with the new 'htmlwidgets' convention.


# aceEditor 1.0.0

* Fixed the 'Save' functionality, which didn't work with UTF8 characters.
* Added the Ace diff editor, highlighting the differences between two files.
* Now the package allows to use multiple editors in the viewer pane with the 
help of `htmltools::browsable`. Some examples are given.


# aceEditor 0.1.0

First release.

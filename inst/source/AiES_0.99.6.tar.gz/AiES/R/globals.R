utils::globalVariables(c("DeD", "InD", "data_sh", "sdat0", "sdat", "file_list.name"))
if (getRversion() >= "2.15.1") utils::globalVariables(c("..ftrTmp"))

library(testthat)
library(AgreementInterval)

test_check("AgreementInterval")

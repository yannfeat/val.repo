#ifndef ADAPTUTILS_H
#define ADAPTUTILS_H

#include <Rcpp.h>
#include <RcppArmadillo.h>

#include "basic_funcs/main_utils.h"
#include "basic_funcs/mats_utils.h"
#include "basic_funcs/input_utils.h"

#endif

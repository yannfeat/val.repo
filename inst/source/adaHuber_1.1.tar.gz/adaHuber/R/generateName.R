#' @useDynLib adaHuber
#' @importFrom Rcpp evalCpp
NULL

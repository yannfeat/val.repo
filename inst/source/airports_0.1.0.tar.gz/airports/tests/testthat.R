library(testthat)
library(airports)

test_check("airports")

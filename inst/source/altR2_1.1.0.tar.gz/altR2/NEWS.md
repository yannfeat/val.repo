# altR2 1.1.0

* Added `estimate_adj_R2` such that the package can also be called when R-squared is not directly estimated from `lm`

library(testthat)
library(altR2)

test_check("altR2")

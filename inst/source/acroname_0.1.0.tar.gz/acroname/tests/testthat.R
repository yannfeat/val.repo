library(testthat)
library(acroname)

test_check("acroname")

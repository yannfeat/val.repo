library(testthat)
library(aire.zmvm)
library(sp)

test_check("aire.zmvm")

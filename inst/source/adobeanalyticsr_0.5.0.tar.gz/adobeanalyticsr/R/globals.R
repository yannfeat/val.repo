utils::globalVariables(c("itemId", "value", "metric", "data", "name",
                         'dataAnomalyDetected', 'dataLowerBound',
                         'dataUpperBound', 'day', 'eventnm', 'qickview',
                         'columnId', 'filters', 'filtername', 'mfinalname',
                         'pred_items', 'pred_list', 'segmentIds', 'metrics',
                         'components', 'status'))

library(testthat)
library(adobeanalyticsr)

test_check("adobeanalyticsr")

library(testthat)
library(ACEsimFit)

test_check("ACEsimFit")

library(testthat)
library(agricolaeplotr)
library(agricolae)
test_check("agricolaeplotr")

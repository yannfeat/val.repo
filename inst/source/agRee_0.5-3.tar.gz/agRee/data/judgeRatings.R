judgeRatings <- matrix(c(2, 4, 3, 3,
                         5, 7, 5, 6,
                         1, 3, 1, 2,
                         7, 9, 9, 8,
                         2, 4, 6, 1,
                         6, 8, 8, 4), nrow=6, byrow=TRUE)

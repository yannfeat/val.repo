# defunct functions give good error messaging!

    Code
      reaggregate_interval_rates()
    Condition <defunctError>
      Error in `reaggregate_interval_rates()`:
      ! `reaggregate_interval_rates` was removed in the 0.0.8 release of ageutils. Going forward please use the function `reaggregate_rates()`.

---

    Code
      reaggregate_interval_counts()
    Condition <defunctError>
      Error in `reaggregate_interval_counts()`:
      ! `reaggregate_interval_counts` was removed in the 0.0.8 release of ageutils. Going forward please use the function `reaggregate_counts()`.

---

    Code
      split_interval_counts()
    Condition <defunctError>
      Error in `split_interval_counts()`:
      ! `split_interval_counts` was removed in the 0.0.8 release of ageutils.

---

    Code
      aggregate_age_counts()
    Condition <defunctError>
      Error in `aggregate_age_counts()`:
      ! `aggregate_age_counts` was removed in the 0.0.8 release of ageutils.


#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom rlang check_dots_empty0
#' @importFrom stats ave
#' @importFrom tibble new_tibble
#' @importFrom vctrs new_data_frame vec_group_loc vec_chop list_unchop
## usethis namespace: end
NULL

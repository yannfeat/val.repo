---
output: github_document
---

<!-- README.md is generated from README.Rmd. Please edit that file -->



# ageutils

<!-- badges: start -->
<a href="https://CRAN.R-project.org/package=ageutils" class="pkgdown-release"><img src="https://www.r-pkg.org/badges/version/ageutils" alt="CRAN status" /></a>
<!-- badges: end -->

NOTE: ageutils is still somewhat experimental in nature and should be treated as
such until the 0.1.0 release.

You can install the latest release of ageutils from [CRAN](https://cran.r-project.org/) with:

``` {.r}
install.packages("ageutils")
```

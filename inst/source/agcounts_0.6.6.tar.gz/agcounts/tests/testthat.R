library(testthat)
library(agcounts)
library(reticulate)
library(shinytest2)

test_check("agcounts")

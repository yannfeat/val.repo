alpha <- function(K){ 
  GDINA::attributepattern(K)
}

test_examples() |>
  capture_output()
library(testthat)
library(AmigaFFH)

test_check("AmigaFFH")

w2q <-
function (w) 
{
    return(as.double(w/(1 + w)))
}

export_lines <-
function () 
{
    fixedlines <- get(data(fixedlines, envir = environment()))
    return(fixedlines)
}

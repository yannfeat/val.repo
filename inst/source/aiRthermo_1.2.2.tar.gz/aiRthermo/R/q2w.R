q2w <-
function (q) 
{
    return(as.double(q/(1 - q)))
}

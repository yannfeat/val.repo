select *
from @cdm_database_schema.cdm_source

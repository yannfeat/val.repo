select *
from @cdm_database_schema.metadata

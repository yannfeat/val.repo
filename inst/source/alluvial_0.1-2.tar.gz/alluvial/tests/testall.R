library(testthat)
library(alluvial)

test_check("alluvial")

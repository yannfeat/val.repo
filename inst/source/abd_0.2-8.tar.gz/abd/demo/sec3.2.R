
xyplot(speed.after ~ speed.before, SpiderSpeed)
# Figure 3.2-2
bwplot(~speed.before, SpiderSpeed)
bwplot(~speed.after, SpiderSpeed)

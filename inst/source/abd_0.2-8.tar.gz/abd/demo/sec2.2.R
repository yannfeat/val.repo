# Figure 2.2-1
plotCumfreq(~ count, DesertBirds, xlab = "Species Abundance")

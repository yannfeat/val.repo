## Run demo for section 9.4
demo(sec9.4)

#' Date add function to be passed along to SQL
#'
#'
#' @param ... additional arguments passed to dbplyr SQL
#' @keywords internal
#' @return Internal, passed along to dbplyr SQL.
DATE_ADD <- function(...) {}

#' Date add function to be passed along to SQL
#'
#'
#' @param ... additional arguments passed to dbplyr SQL
#' @keywords internal
#' @return Internal, passed along to dbplyr SQL.
DATE_DIFF <- function(...) {}

#' Date add function to be passed along to SQL
#'
#'
#' @param ... additional arguments passed to dbplyr SQL
#' @keywords internal
#' @return Internal, passed along to dbplyr SQL.
STRING_AGG <- function(...) {}

#' Date add function to be passed along to SQL
#'
#'
#' @param ... additional arguments passed to dbplyr SQL
#' @keywords internal
#' @return Internal, passed along to dbplyr SQL.
CAST <- function(...) {}

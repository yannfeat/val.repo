#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom lifecycle deprecated
#' @importFrom rlang :=
#' @importFrom rlang .data
#' @importFrom stats lag
#' @importFrom utils capture.output
#' @importFrom utils download.file
#' @importFrom utils example
#' @importFrom utils packageVersion
#' @importFrom utils read.csv
#' @importFrom utils untar
#' @importFrom utils head
## usethis namespace: end
NULL

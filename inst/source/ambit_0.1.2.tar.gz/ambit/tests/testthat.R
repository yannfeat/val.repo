library(testthat)
library(ambit)

test_check("ambit")

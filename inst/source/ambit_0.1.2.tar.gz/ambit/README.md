# ambit
Simulation and estimation tools for 
    various types of ambit processes, including trawl processes and weighted
    trawl processes.

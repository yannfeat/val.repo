test_asymnorm(ahat=0.9, n=5000, Delta=0.1, k=1, c4=1, varlevyseed=1,
              trawlfct="Exp", trawlfct_par=0.1)

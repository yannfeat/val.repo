library(testthat)
library(adea)

test_check("adea")

# AIscreenR 0.2.0

* Minor change in the setup of the vignette
* Updated prize data, including all up-to-date models
* Adding create_fine_tune_data() and write_fine_tune_data() to generate data for fine tuning OpenAI's models
* Adding Thomas Olsen as co-author

# AIscreenR 0.1.1 

* A typo in the vignette has been corrected.
* The vignette now draws on functions from synthesisr instead of revtools to handle RIS files. 
* tabscreen_gpt() now treats the study ID variable as a factor to keep original order of the dataset with titles and abstracts. 

# AIscreenR 0.1.0

* This is the first release of AIscreenR.

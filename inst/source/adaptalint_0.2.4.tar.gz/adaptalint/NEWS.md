# adaptalint 0.2.4

- Small change to tests to work with new R version
- Readme typos

# adaptalint 0.2.3

- Improved description
- Improved examples
- Added two new functions for single files

# adaptalint 0.2.0

- Fix for namespace issue where I forgot to export check_with_style.
- Improved and extended tests.
- Added more detail to readme.
- Renamed check_with_style to lint_with_style

# adaptalint 0.1.0

- Initial version
- Added a `NEWS.md` file to track changes to the package.




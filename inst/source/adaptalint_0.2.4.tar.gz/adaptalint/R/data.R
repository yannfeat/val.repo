#' A style extracted from a popular package, included for convenience
#' @family bundled_styles
'style_plyr'

#' A style extracted from a popular package, included for convenience
#' @family bundled_styles
'style_dplyr'

#' A style extracted from a popular package, included for convenience
#' @family bundled_styles
'style_purrr'

#' A style extracted from a popular package, included for convenience
#' @family bundled_styles
'style_tidyr'

#' A style extracted from a popular package, included for convenience
#' @family bundled_styles
'style_fbar'

#' A style extracted from a popular package, included for convenience
#' @family bundled_styles
'style_gsheet'

#' A style extracted from a popular package, included for convenience
#' @family bundled_styles
'style_adaptalint'

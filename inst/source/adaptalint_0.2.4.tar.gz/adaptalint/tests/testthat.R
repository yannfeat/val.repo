library(testthat)
library(adaptalint)

test_check("adaptalint")

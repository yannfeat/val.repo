# allestimates 0.2.3
all_speedglm no longer available. 

# allestimates 0.2.0
Fixed an issue with the new version of 'speedglm' 0.3-3. 'all_speedglm' no longer depends on 'broom' to void this problem. 

# allestimates 0.1.9

* Fixed an issue of 'speedglm' p values as previously used 'broom::tidy' cannot pick up P values from 'speedglm'. 

# allestimates 0.1.8
*Fixed a dependency issue with the new version of 'broom' 0.7.0: 'conf.int = TRUE' added in 'all_cox'. 

# allestimates 0.1.7
*Fixed a dependency issue with the new version of 'broom' 0.7.0: 'conf.int = TRUE' added in 'all_cox'. 

# allestimates 0.1.6
* corrections in description and removed \dontrun{}. 
# allestimates 0.1.5
* Document edited. 

# allestimates 0.1.4

* Description text: added what models the package supports
* Removed all \dontrun{} and examples can be tested. 

# allestimates 0.1.3

* This is a new submission to CRAN. 

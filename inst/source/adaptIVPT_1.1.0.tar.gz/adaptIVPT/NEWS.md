# adaptIVPT v 1.1.0
+ `msabe`
+ `rss`
+ `prms`
+ `PRsurface`

Currently, only supporting balanced data and parallel replicate design.

## New features
+ The first version of **adaptIVPT** providing functions that help design and analyze IVPT studies.
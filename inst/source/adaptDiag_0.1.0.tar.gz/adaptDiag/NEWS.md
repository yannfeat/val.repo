# adaptDiag 0.1.0

* First package release to CRAN.

library(testthat)
library(adaptDiag)

test_check("adaptDiag")

#' 1000 5-dimensional data points that form ten clusters
#' 
#' Generated from the genRandomClust() function of the "clusterGeneration" package with separation value 0.2.
#'  
#' @docType data
#' @keywords datasets
#' @format data frame
#' @name clust10
NULL

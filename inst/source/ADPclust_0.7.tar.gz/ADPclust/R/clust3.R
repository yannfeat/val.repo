#' 90 2-dimensional data points that form three clusters
#' 
#' Randomly generated from three normal distributions.
#'  
#' @docType data
#' @keywords datasets
#' @format data frame
#' @name clust3
NULL

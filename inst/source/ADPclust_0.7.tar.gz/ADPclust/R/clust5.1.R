#' 500 5-dimensional data points that form five clusters
#' 
#' Generated from the genRandomClust() function of the "clusterGeneration" package with separation value 0.01 (tightly clustered).
#'  
#' @docType data
#' @keywords datasets
#' @format data frame
#' @name clust5.1
NULL

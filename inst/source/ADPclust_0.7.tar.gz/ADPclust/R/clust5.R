#' 500 5-dimensional data points that form five clusters
#' 
#' 500 5-dim points in 5 clusters. Generated from the genRandomClust() function of the "clusterGeneration" package with separation value 0.1.
#'  
#' @docType data
#' @keywords datasets
#' @format data frame
#' @name clust5
NULL

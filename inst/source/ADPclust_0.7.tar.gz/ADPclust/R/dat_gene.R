#' 243-dimensional gene expression data of 38 patients (243 genes) 
#' 
#' 38 by 243 matrix. Each row represents a patient. Each column represents a gene.
#'  
#' @docType data
#' @keywords datasets
#' @format matrix
#' @name dat_gene
NULL

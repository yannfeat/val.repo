##' Returns 10 default colors
##'
##' @title Default colors
##' @return vector of colors
defCol <- function(){
    mycols <- c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3",
                "#FF7F00", "#FFFF33", "#A65628", "#F781BF", "#999999", "blue")
    return(mycols)
}

library(testthat)
library(ADPclust)

test_check("ADPclust")

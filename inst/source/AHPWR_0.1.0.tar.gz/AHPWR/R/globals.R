 utils::globalVariables(c("Alternativas", "Pesos", "Ranque", "label", "s_e", "step", "type", "x" ,"xmax" ,"xmin", "y" ,"ymax", "ymin"))


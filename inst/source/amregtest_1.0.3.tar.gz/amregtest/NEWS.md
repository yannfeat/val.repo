# amregtest 1.0.3

## New features

* First version delivered to CRAN.

* 'allelematch' versions tested so far: 2.5.4, 2.5.3 and 2.5.2
  (2.5.1 and earlier no longer runs on modern versions of R)

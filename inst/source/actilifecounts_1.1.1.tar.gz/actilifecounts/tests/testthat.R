library(testthat)
library(actilifecounts)

testthat::test_check("actilifecounts")

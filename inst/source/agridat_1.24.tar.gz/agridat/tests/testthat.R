library(testthat)
library(agridat)

test_check("agridat")

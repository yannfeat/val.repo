library(testthat)
library(adc)

test_check("adc")

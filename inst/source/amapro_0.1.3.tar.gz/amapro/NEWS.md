# amapro (development version 0.1.2.02)
* upgrade amap.js to v.2.0.5.10
* tested with latest loca.js - many errors, kept older file
* fixed: Loca load at am.init, key popup to be topmost
* added tests, all Loca layers
* pkgdown website

# amapro 0.1.1
* fixing documentation notes for CRAN

# amapro 0.1.0
* initial release, resubmit to CRAN Jul 20, 2022

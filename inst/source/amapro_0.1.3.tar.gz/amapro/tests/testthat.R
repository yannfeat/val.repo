library(testthat)
library(amapro)

test_check("amapro")

# alpha-correction-bh 0.0.2

* Bugfix: All alphas should be non-significant once the first alpha value check comes back non-significant.

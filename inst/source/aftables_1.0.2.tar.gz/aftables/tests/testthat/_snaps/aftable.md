# tbl output looks as intended

    # aftable: 3 x 7
      tab_title sheet_type sheet_title blank_cells source custom_rows table         
      <chr>     <chr>      <chr>       <chr>       <chr>  <list>      <list>        
    1 A         cover      A           <NA>        <NA>   <chr [1]>   <df [1 x 1]>  
    2 B         contents   B           <NA>        <NA>   <chr [1]>   <df [1 x 2]>  
    3 C         tables     C           <NA>        Source <chr [1]>   <df [32 x 11]>


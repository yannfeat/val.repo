library(testthat)
library(aftables)

test_check("aftables")

# Pre-compiled vignettes that take long to run
knitr::knit("vignettes/ascariasis.Rmd.orig", "vignettes/ascariasis.Rmd")
knitr::knit("vignettes/simulation_study.Rmd.orig", "vignettes/simulation_study.Rmd")

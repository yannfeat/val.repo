get_incompleteness = function(x){
  
  #' 
  #' @export
  #' 
  
  UseMethod("get_incompleteness")
  
}
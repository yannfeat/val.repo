get_hiat_no.adm = function(x){
  
  #'
  #' @export
  #' 
  
  return(length(get_hiat_pos(x)))
}
print.adm = function(x, ...){
  
  #'
  #' @export
  #' @noRd
  
  cat("age-depth model")
  return(invisible())
}

print.multiadm = function(x, ...){
  
  #'
  #' @export
  #' @noRd
  
  cat("Collection of age-depth models")
  return(invisible())
}

print.sac = function(x, ...){
  #' @export
  #' @noRd
  cat("sediment accumulation curve")
  return(invisible())
}
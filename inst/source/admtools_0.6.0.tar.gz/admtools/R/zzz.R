
  
  .adm_plot_env <- new.env()

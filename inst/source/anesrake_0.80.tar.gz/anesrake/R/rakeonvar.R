rakeonvar <- function(weighton, weightto, weightvec)
  UseMethod("rakeonvar")


discrep <-
function(datavec, targetvec, weightvec)
  UseMethod("discrep")


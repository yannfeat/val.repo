library(testthat)
library(aiRly)

test_check("aiRly")

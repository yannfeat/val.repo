library(testthat)
library(actxps)

test_check("actxps")

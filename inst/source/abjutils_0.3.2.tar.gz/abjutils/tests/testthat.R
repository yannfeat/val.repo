library(testthat)
library(abjutils)

test_check("abjutils")

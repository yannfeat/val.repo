# abjutils 0.3.2

* Updated README
* Added pkgdown
* Changed travis/appveyor to github actions

# abjutils 0.3.1

* Fixed maintainer information

# abjutils 0.3.0

* Change maintainer email
* Removed deprecated functions (pvec() and use_pipe())
* Added a `NEWS.md` file to track changes to the package.

library(testthat)
library(accessrmd)

test_check("accessrmd")

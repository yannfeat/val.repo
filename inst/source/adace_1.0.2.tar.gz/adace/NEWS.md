# adace 1.0.2

- Second release of adherer's estimands. 
- Version 2 updates: fixed estimation of standard errors and 
relaxed assumption of dropout before the first timepoint. 

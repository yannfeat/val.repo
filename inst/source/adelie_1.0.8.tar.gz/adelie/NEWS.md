# adelie (development version)

# adelie 1.0.1

* Added fixes to UBSAN issues in `IOSNPUnphased` and `IOSNPPhasedAncestry` classes.
* Added fixes to UBSAN issues in exporting `RStateMultiGlm64`.

# adelie 1.0.0

* Added a `NEWS.md` file to track changes to the package.

#include <tools/eigen_wrap.hpp>
#include <adelie_core/glm/glm_multinomial.ipp>

template class adelie_core::glm::GlmMultinomial<float>;
template class adelie_core::glm::GlmMultinomial<double>;
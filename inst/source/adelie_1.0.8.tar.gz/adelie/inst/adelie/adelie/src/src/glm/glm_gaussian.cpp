#include <tools/eigen_wrap.hpp>
#include <adelie_core/glm/glm_gaussian.ipp>

template class adelie_core::glm::GlmGaussian<float>;
template class adelie_core::glm::GlmGaussian<double>;
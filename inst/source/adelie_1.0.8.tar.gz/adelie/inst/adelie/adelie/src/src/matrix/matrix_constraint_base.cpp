#include <tools/eigen_wrap.hpp>
#include <adelie_core/matrix/matrix_constraint_base.ipp>

template class adelie_core::matrix::MatrixConstraintBase<float>;
template class adelie_core::matrix::MatrixConstraintBase<double>;
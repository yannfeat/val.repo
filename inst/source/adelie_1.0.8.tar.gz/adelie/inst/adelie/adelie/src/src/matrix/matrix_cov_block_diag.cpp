#include <tools/eigen_wrap.hpp>
#include <adelie_core/matrix/matrix_cov_block_diag.ipp>

template class adelie_core::matrix::MatrixCovBlockDiag<float>;
template class adelie_core::matrix::MatrixCovBlockDiag<double>;
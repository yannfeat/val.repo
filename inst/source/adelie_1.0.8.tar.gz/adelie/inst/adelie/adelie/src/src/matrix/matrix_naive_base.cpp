#include <tools/eigen_wrap.hpp>
#include <adelie_core/matrix/matrix_naive_base.ipp>

template class adelie_core::matrix::MatrixNaiveBase<float>;
template class adelie_core::matrix::MatrixNaiveBase<double>;
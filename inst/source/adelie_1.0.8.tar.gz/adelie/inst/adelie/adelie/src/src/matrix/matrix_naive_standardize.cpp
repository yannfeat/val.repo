#include <tools/eigen_wrap.hpp>
#include <adelie_core/matrix/matrix_naive_standardize.ipp>

template class adelie_core::matrix::MatrixNaiveStandardize<float>;
template class adelie_core::matrix::MatrixNaiveStandardize<double>;
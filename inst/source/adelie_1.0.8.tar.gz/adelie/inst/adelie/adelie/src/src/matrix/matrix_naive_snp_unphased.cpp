#include <tools/eigen_wrap.hpp>
#include <adelie_core/matrix/matrix_naive_snp_unphased.ipp>

template class adelie_core::matrix::MatrixNaiveSNPUnphased<float>;
template class adelie_core::matrix::MatrixNaiveSNPUnphased<double>;
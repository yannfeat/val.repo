#include <tools/eigen_wrap.hpp>
#include <adelie_core/matrix/matrix_naive_snp_phased_ancestry.ipp>

template class adelie_core::matrix::MatrixNaiveSNPPhasedAncestry<float>;
template class adelie_core::matrix::MatrixNaiveSNPPhasedAncestry<double>;
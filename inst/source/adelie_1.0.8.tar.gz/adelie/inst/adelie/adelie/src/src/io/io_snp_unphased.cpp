#include <tools/eigen_wrap.hpp>
#include <adelie_core/io/io_snp_unphased.ipp>

template class adelie_core::io::IOSNPUnphased<>;
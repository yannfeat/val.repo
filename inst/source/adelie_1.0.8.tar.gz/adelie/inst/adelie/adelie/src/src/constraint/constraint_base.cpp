#include <tools/eigen_wrap.hpp>
#include <adelie_core/constraint/constraint_base.ipp>

template class adelie_core::constraint::ConstraintBase<float>;
template class adelie_core::constraint::ConstraintBase<double>;
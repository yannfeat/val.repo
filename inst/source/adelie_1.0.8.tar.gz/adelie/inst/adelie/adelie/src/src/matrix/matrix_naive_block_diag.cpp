#include <tools/eigen_wrap.hpp>
#include <adelie_core/matrix/matrix_naive_block_diag.ipp>

template class adelie_core::matrix::MatrixNaiveBlockDiag<float>;
template class adelie_core::matrix::MatrixNaiveBlockDiag<double>;
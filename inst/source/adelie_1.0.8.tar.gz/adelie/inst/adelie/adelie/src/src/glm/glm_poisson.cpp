#include <tools/eigen_wrap.hpp>
#include <adelie_core/glm/glm_poisson.ipp>

template class adelie_core::glm::GlmPoisson<float>;
template class adelie_core::glm::GlmPoisson<double>;
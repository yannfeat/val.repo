#include <tools/eigen_wrap.hpp>
#include <adelie_core/matrix/matrix_cov_base.ipp>

template class adelie_core::matrix::MatrixCovBase<float>;
template class adelie_core::matrix::MatrixCovBase<double>;
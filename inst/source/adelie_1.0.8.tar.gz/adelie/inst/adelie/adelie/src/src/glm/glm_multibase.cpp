#include <tools/eigen_wrap.hpp>
#include <adelie_core/glm/glm_multibase.ipp>

template class adelie_core::glm::GlmMultiBase<float>;
template class adelie_core::glm::GlmMultiBase<double>;
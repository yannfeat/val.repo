#include <tools/eigen_wrap.hpp>
#include <adelie_core/glm/glm_base.ipp>

template class adelie_core::glm::GlmBase<float>;
template class adelie_core::glm::GlmBase<double>;
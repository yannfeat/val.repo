#include <tools/eigen_wrap.hpp>
#include <adelie_core/constraint/constraint_box.ipp>

template class adelie_core::constraint::ConstraintBox<float>;
template class adelie_core::constraint::ConstraintBox<double>;
#include <tools/eigen_wrap.hpp>
#include <adelie_core/io/io_snp_base.ipp>

template class adelie_core::io::IOSNPBase<>;
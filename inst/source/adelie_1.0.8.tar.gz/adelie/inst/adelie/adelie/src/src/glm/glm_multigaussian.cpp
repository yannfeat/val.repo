#include <tools/eigen_wrap.hpp>
#include <adelie_core/glm/glm_multigaussian.ipp>

template class adelie_core::glm::GlmMultiGaussian<float>;
template class adelie_core::glm::GlmMultiGaussian<double>;
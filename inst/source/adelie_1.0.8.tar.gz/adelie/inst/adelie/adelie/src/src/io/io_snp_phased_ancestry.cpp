#include <tools/eigen_wrap.hpp>
#include <adelie_core/io/io_snp_phased_ancestry.ipp>

template class adelie_core::io::IOSNPPhasedAncestry<>;
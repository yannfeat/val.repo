#include <tools/eigen_wrap.hpp>
#include <adelie_core/matrix/matrix_naive_subset.ipp>

template class adelie_core::matrix::MatrixNaiveCSubset<float>;
template class adelie_core::matrix::MatrixNaiveCSubset<double>;
template class adelie_core::matrix::MatrixNaiveRSubset<float>;
template class adelie_core::matrix::MatrixNaiveRSubset<double>;
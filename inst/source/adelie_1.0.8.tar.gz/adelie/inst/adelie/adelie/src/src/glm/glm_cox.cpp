#include <tools/eigen_wrap.hpp>
#include <adelie_core/glm/glm_cox.ipp>

template class adelie_core::glm::GlmCox<float>;
template class adelie_core::glm::GlmCox<double>;
#pragma once
#include <Rcpp.h>
#include <RcppEigen.h>

namespace adelie_core {}
namespace ad = adelie_core;

## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----message=FALSE------------------------------------------------------------
library(ade4)
library(adegraphics)

## ----eval=FALSE---------------------------------------------------------------
# adegraphics::s.label()


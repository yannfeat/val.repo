# acdcquery 1.1.0

* Results from `query_db()` now only return distinct entries for all tables except the observation table
* Improved matching speed by only selecting variables from tables required by filter arguments and return arguments
* Made the package compatible to work with the Truth Effect Database (TED)

# acdcquery 1.0.1

* Removed acdc.db. Changed examples

# acdcquery 1.0.0

* Initial release version

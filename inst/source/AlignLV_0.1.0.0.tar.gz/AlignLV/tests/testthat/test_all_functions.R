#all non-trivial functions exported and demonstrated in examples;
# test_that not used

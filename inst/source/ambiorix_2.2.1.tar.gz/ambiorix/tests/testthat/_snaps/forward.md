# forward

    Code
      f
    Output
      Using next method


# Request cookie

    Code
      parser
    Message
      i A cookie parser

---

    Code
      cook
    Message
      i A cookie: hello = "world"


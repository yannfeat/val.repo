# Websocket

    Code
      ws
    Message
      i receive: `receive(message, ws)`
        * Listening on message:
      * name: "hello"

---

    Code
      ws
    Message
      * send: `send(name, message)`


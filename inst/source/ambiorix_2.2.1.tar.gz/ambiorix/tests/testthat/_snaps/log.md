# log

    Code
      success()
    Output
      <cli_ansi_string>
      [1] v

---

    Code
      error()
    Output
      <cli_ansi_string>
      [1] x

---

    Code
      info()
    Output
      <cli_ansi_string>
      [1] i

---

    Code
      warn()
    Output
      <cli_ansi_string>
      [1] !


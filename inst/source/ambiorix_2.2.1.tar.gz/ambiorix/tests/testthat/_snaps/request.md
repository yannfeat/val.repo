# Request

    Code
      req
    Message
      
      -- A Request 
        * HEADERS:
        text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9,
        gzip, deflate, br, en-US,en;q=0.9, keep-alive, localhost:13698, " Not
        A;Brand";v="99", "Chromium";v="99", ?0, "Linux", document, navigate, none,
        ?1, 1, and Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like
        Gecko) Chrome/99.0.4844.82 Safari/537.36
        * HTTP_ACCEPT:
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"
        * HTTP_ACCEPT_ENCODING: "gzip, deflate, br"
        * HTTP_ACCEPT_LANGUAGE: "en-US,en;q=0.9"
        * HTTP_CACHE_CONTROL:
        * HTTP_CONNECTION: "keep-alive"
        * HTTP_COOKIE: ""
        * HTTP_HOST: "localhost:13698"
        * HTTP_SEC_FETCH_DEST: "document"
        * HTTP_SEC_FETCH_MODE: "navigate"
        * HTTP_SEC_FETCH_SITE: "none"
        * HTTP_SEC_FETCH_USER: "?1"
        * HTTP_UPGRADE_INSECURE_REQUESTS: "1"
        * HTTP_USER_AGENT: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36
        (KHTML, like Gecko) Chrome/99.0.4844.82 Safari/537.36"
        * httpuv.version 1.6.5
        * PATH_INFO: "/"
        * QUERY_STRING: ""
        * REMOTE_ADDR: "127.0.0.1"
        * REMOTE_PORT: "44328"
        * REQUEST_METHOD: "GET"
        * SCRIPT_NAME: ""
        * SERVER_NAME: "127.0.0.1"
        * SERVER_PORT: "127.0.0.1"
        * CONTENT_LENGTH:
        * CONTENT_TYPE:
        * HTTP_REFERER:
        * rook.version: "1.1-0"
        * rook.url_scheme: "http"
        * params: "params"
    Output
      List of 1
       $ x: num 1
    Message
        * query: "query"
    Output
      List of 1
       $ x: num 1


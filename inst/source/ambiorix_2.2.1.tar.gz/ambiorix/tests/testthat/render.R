library(htmltools)

tags$html(
  tags$title("[% title %]"),
  tags$body(
    p("hello")
  )
)

library(testthat)
library(ambiorix)

test_check("ambiorix")

## Vector of years expressed in ka BP
(x <- fixed(c(30, 35, 40), calendar = BP(), scale = 1000))
format(x)

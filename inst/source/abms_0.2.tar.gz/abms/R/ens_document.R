#' Chilean National Health Survey (2016-2017)
#' @description \code{ens} is a data-base that reo collected by the Chilean National Health Survey in order to study the health status of the population and policy making. This survey was performed between 2016 and 2017
#' @format A Data frame with 3238 rows and 15 variables (columns):
#' \describe{
#'		\item{\code{pas}}{Blood systolic pressure}
#'		\item{\code{pad}}{Blood diastolic pressure}
#'		\item{\code{age}}{In years}
#'		\item{\code{waist}}{diameter in centimeters}
#'		\item{\code{bmi}}{body mass index}
#'		\item{\code{weight}}{In centimeters}
#'		\item{\code{height}}{In centimeters}
#'		\item{\code{hypertension}}{Presence of hypertension (1: Yes, 0: No)}
#'		\item{\code{sedentary}}{sedentary person (1: Yes, 0: No)}
#'		\item{\code{smoker}}{1: Yes, 0: No}
#'		\item{\code{diabetes}}{1: Yes, 0: No}
#'		\item{\code{depression}}{1: Yes, 0: No}
#'		\item{\code{male}}{1: Yes, 0: female}
#'		\item{\code{scholar}}{Years of formal education}}
#' @source{Chilean Health Ministry (https://epi.minsal.cl/encuesta-ens-anteriores/)}
#' @examples
#' data(ens)
"ens"

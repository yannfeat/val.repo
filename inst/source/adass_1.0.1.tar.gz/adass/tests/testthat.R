library(testthat)
library(adass)

test_check("adass")

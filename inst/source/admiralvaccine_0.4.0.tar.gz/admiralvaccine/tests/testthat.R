library(testthat)
library(admiralvaccine)

test_check("admiralvaccine")

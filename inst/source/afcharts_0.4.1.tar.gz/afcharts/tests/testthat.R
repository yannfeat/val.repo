library(testthat)
library(afcharts)
test_check("afcharts")

# afcharts 0.4.1

-   Fixed bug which prevented some functions from working if called directly without attaching the package.

-   Fixed bug in `use_afcharts` when passing args to `theme_af`.

-   `scale_colour_discrete_af` and `scale_fill_discrete_af` now inform rather than warn when the `main2` colour palette is used instead of `main` if only two colours are required.

# afcharts 0.4.0

First release of package based on [sgplot](https://scotgovanalysis.github.io/sgplot/).

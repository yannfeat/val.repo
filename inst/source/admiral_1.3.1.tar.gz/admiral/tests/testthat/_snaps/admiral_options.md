# get_admiral_option Test 2: common typo gives error to select available options

    Code
      get_admiral_option("subject_key")
    Condition
      Error in `get_admiral_option()`:
      ! Invalid function argument.
      i Select one of "subject_keys", "signif_digits", or "save_memory"


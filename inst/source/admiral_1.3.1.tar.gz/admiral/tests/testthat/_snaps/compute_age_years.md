# compute_age_years Test 3: Error is issued when `age_unit` has invalid length

    Code
      compute_age_years(age_input, age_unit_input)
    Condition
      Error in `compute_age_years()`:
      ! Argument `age_unit` must be a single string or a vector of the same length as `age`
      i There are 3 values in `age` and 2 values in `age_unit`.


# print_named_list Test 18: named list with unamed list

    Code
      print_named_list(list(list_item = list("Hello World!", expr(universe), list(42)),
      another_one = ymd("2020-02-02")))
    Output
      list_item:
        "Hello World!"
        universe
        42
      another_one: 2020-02-02


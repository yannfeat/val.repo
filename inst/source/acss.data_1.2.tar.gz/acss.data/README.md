acss_data: Data only package
=========

## Algorithmic Complexity of Short Strings (Computed via Coding Theorem Method)

This is a data only package and should not be directly used. Instead, access the contents of this package through the `acss` package, which can be installed via:

```
install.packages("acss")
```


utils::globalVariables(c("a", ".", "N", "RET"))

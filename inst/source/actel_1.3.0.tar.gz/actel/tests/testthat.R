library(testthat)
library(actel)

test_check("actel")
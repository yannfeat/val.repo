# alfred 0.2.1
* Fixed deprecated tidyr verbs

# alfred 0.2.0
* Fixed error messages

# alfred 0.1.12 
* Added the option to supply your own API key
* Building the vignette is skipped if there is no internet

# alfred 0.1.11 
* Minor fix for handling of failed downloads if connection refused by API

# alfred 0.1.10 
* Minor fix for handling of failed downloads, tests are skipped without internet connection

# alfred 0.1.9 
* Minor fix for curl dependency on macOS

# alfred 0.1.8 
* Minor fix for future compatibility with dplyr

# alfred 0.1.7 
* Test fixed

# alfred 0.1.6 
* Test fixed

# alfred 0.1.5 
* Re-added vignette

# alfred 0.1.4 
* Bug-fix in error-handling

# alfred 0.1.3 
* Faster download due to using jsonlite insteal of xml2

# alfred 0.1.2 
* Inconsistent use of real time und realtime fixed

# alfred 0.1.1 
* Updated documentation etc.

# alfred 0.1.0 
* Initial submission to CRAN

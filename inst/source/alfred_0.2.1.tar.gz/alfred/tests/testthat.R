library(testthat)
library(alfred)

test_check("alfred")

# allometry 0.1.1

* Minor fixes for the CRAN release.

# allometry 0.1.0

* Initial release.


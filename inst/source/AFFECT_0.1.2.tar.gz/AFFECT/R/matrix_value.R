calculation<- function(x){
  values <- x-mean(x)
  return(values)
}

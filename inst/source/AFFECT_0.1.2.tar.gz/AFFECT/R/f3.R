f3 <- function(x3){
  y <- cos(6*x3)-1
  return(y)
}


f4 <- function(x4){
  y <- 4*x4^3+x4^2
  return(y)
}

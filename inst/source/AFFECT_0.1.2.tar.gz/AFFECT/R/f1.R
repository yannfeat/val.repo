f1 <- function(x1){
  y <- 4*x1^2+x1
  return(y)
}

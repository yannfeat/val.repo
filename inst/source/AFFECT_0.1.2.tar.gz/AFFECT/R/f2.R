f2 <- function(x2){
  y <- sin(6*x2)
  return(y)
}

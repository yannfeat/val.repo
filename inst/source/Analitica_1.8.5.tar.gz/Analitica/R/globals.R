utils::globalVariables(c("variacion", "Grupo", "Media", "Letra", "ylim"))
utils::globalVariables(c("Mean", "SD", "variation_value", "Group"))

library(testthat) # nolint: undesirable_function_linter
library(admiralpeds) # nolint: undesirable_function_linter

test_check("admiralpeds")

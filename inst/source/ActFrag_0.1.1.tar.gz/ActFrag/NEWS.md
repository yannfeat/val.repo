# ActFrag

10 Feb 2020

#Fixed problem when using the option metrics is selected to be only one of the fragmentation metrics. 





## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib adaR, .registration = TRUE
## usethis namespace: end
NULL

# addinslist 0.5.0 (2023-05-14)

- Fix bug: on some MacOS systems the addins was crashing because of invalid path names (#124) 

# addinslist 0.4.0 (2021-01-08)

- Fix bug: addins weren't able to get installed in modern browsers (#117)

# addinslist 0.3 (2019-08-30)

- make sure pre-installed dependencies are never updated when installing a package from GitHub
- swap `devtools` package for `remotes`

# addinslist 0.2 (2016-09-28)

- remove deprecated xml2 function

library(testthat)
library(adoptr)

test_check("adoptr")

library(testthat) # nolint: undesirable_function_linter
library(admiralmetabolic) # nolint: undesirable_function_linter

test_check("admiralmetabolic")

list(
  rd_family_title = list(
    der_adxx = "ADXX Functions that returns variable appended to dataset: ",
    der_prm_advs = "ADVS Functions for adding Parameters: ",
    com_adxx = "ADXX Functions that returns a vector: ",
    utils_ds_chk = "Utilities for Dataset Checking: ",
    utils_fil = "Utilities for Filtering Observations: ",
    utils_fmt = "Utilities for Formatting Observations: ",
    utils_help = "Utilities used within Derivation functions: ",
    utils_examples = "Utilities used for examples and template scripts: ",
    source_specifications = "Source Specifications: ",
    high_order_function = "Higher Order Functions: "
  )
)


# anim.plots 0.2.3

* Documentation fixes for HTML manuals on CRAN.

# anim.plots 0.2.2

* Tweaks to fix R CMD check.
* Fixed a warning in `anim.arrows()`.

# anim.plots 0.2.1

* Added a `NEWS.md` file to track changes to the package.
* Moved full vignette to a subdirectory of doc/ to satisfy CRAN checks.


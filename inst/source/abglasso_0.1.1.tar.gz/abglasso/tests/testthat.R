library(testthat)
library(abglasso)

test_check("abglasso")

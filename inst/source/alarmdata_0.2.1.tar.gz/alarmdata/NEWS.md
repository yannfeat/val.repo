# alarmdata 0.2.1

* Adds support for 2010 50-state simulation data.
* Prepare for CRAN release

# alarmdata 0.1.0

* Initial package release
* Functionality to download 50-state simulation data, 2020 Census + VEST data,
  and add additional plans to simulation objects

#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom cli cli_abort cli_warn cli_inform
#' @importFrom dplyr %>% .data
#' @importFrom rlang := .env
#' @importFrom utils browseURL
## usethis namespace: end
NULL

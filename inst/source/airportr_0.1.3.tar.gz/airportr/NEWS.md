# airportr 0.1.3

* Added a `NEWS.md` file to track changes to the package.
* Added 514 new airports including 78 in the United States, 61 in China, 37 in Australia, and 34 in Greenland of all places. 
* Added ability to limit airport lookups by any ISO country code in addition to country name. Thanks to @danim25 for the suggestion. 

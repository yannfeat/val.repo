#' @keywords internal
#' @md
#' @name AgroReg-package
#' @docType package
"_PACKAGE"

# air 0.2.3

# air 0.2.3

This patch fixes a potential issue with how warnings from `keyring` are handled.

# air 0.2.2

This is the first CRAN release and showcases two major features:

* `howto()` writes R code given a description.
* `whatis()` gives a written explanation of what given R code does.

library(testthat)
library(acumos)

test_check("acumos")

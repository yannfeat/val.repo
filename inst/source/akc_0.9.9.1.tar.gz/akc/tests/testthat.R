library(testthat)
library(akc)

test_check("akc")

utils::globalVariables('sample-3.aif')
# this exists solely to workaround a stupid rule in check --as-cran 
# that whines about variables not existing in its own workspace 
library(testthat)
library(AirMonitor)

test_check("AirMonitor")

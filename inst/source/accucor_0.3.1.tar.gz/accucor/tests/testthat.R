library(testthat)
library(accucor)

test_check("accucor")

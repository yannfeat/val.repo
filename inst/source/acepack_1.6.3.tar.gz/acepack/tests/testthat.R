library(testthat)
library(acepack)

test_check("acepack")

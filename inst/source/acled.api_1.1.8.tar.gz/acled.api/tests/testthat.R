library(testthat)
library(acled.api)

test_check("acled.api")

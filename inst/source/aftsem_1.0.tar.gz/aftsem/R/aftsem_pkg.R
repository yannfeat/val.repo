#' aftsem: Semiparametric Accelerated Failure Time
#'
#' @aliases aftsem-package
#'
#' @useDynLib aftsem, .registration = TRUE
#' @docType package
"_PACKAGE"
NULL
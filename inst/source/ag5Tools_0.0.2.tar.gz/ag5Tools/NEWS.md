# ag5Tools 0.0.2

## Major changes

-   Add version parameter to function *ag5_download*, now required by AgERA5 database.

## Enhancements

-   Use parallelization to function *ag5_extract* to speed up files search

## Bug fixes

Correct parameter in help of function *ag5_extract* from 24_hour_minimum to Min-24h


# ag5Tools 0.0.1

-   First version on CRAN

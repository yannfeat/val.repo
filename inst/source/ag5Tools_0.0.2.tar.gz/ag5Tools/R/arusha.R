#'Example dataset for the agera5 package
#'
#'100 points in Arusha, Tanzania
#'The geographic coordinates were generated with the function st_sample from package sf
#'
#'
#'
"arusha_df"

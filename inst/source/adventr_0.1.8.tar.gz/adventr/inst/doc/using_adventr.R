## ---- eval = F, include = T---------------------------------------------------
#  learnr::run_tutorial("name_of_tutorial", package = "adventr")

## ---- eval = F, include = T---------------------------------------------------
#  
#  learnr::run_tutorial("adventr_02", package = "adventr")
#  


# agghoo

R package for model selection based on aggregation.
Alternative to standard cross-validation.

## Install the package

From GitHub: `devtools::install_github("yagu0/agghoo")`

Locally, in a terminal: `R CMD INSTALL .`

## Use the package

    library(agghoo)
    ?agghoo

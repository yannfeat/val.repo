library(testthat)
library(AgePopDenom)

test_check("AgePopDenom")

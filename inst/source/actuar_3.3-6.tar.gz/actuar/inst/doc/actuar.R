### R code from vignette source 'actuar.Rnw'

###################################################
### code chunk number 1: actuar.Rnw:48-50 (eval = FALSE)
###################################################
## vignette(package = "actuar")
## demo(package = "actuar")


###################################################
### code chunk number 2: actuar.Rnw:59-61 (eval = FALSE)
###################################################
## citation()
## citation("actuar")



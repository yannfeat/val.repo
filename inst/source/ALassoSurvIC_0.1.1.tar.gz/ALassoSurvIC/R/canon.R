canon <- function(x, len) {
  xx <- rep(0, len)
  xx[x] <- 1
  xx
}

alacoxIC <- function(...) UseMethod("alacoxIC")

library(testthat)
library(afex)

test_check("afex")

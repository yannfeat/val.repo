library(testthat)
library(akiFlagger)

test_check("akiFlagger")

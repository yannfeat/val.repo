test_that("toy dataset loads properly", {
  expect_equal(toy$creatinine[1:5], c(1.05, 1.61, 1.42, 1.26, 1.06))
})

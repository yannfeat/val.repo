`sppResponse` <- function(x, ...) {
  UseMethod("sppResponse")
}

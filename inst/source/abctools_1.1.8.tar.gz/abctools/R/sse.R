sse<-function(a,b,v=1){

sse<-rsse(a,b,v)
sse<-sse^2

return(sse)

}

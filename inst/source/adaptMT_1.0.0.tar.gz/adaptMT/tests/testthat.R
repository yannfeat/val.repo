library(testthat)
library(adaptMT)

test_check("adaptMT")

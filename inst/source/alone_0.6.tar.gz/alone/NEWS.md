# alone v0.6

* Data updates
    - Adding complete Alone Australia Season 3


# alone v0.5

* Data updates
    - Adding complete Alone season 11
    - Episode subtitle and description of IMDb


# alone v0.4

* Data updates
    - Adding complete Alone Australia season 2 data
    - Adding complete Alone: Frozen data


# alone v0.3

* Data updates
    - Adding complete season 10 data

# alone v0.2


* Data updates
    - Adding Alone Australia
    - Adding cast for season 10
* New features
    - first name
    - last name
    - number remaining at start of episode (for AU only)
    - day at start of episode (for AU only)


# alone v0.1.1

* New features added
  * Survivalist image URL
  * Survivalist ID
* Minor data fixes


# alone v0.1.0

Now on CRAN!

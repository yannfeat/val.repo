# anabel 3.0.2

## Minor improvements and bug fixes:

* bug fix: Std value calculation corrected
* updated links to new frontend
* updated licence

# anabel 3.0.1

## Minor improvements and bug fixes:

* No reports are generated during package testing.
* Source of datasets was set to Simul8 software in the data documentation as well.
* remove fourth digit from package version that indicate dev mode.
* Added a `NEWS.md` file to track changes to the package.

# anabel 3.0.0

* package released

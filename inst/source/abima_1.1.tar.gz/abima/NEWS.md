# abima 1.1

* Updated the document.

# abima 1.0

* Initial CRAN submission.

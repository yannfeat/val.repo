library(testthat)
library(afdx)

test_check("afdx")

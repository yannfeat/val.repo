# afdx development


## Pre-release development
* 1.1.1 Updated date

* 1.1.0 Improve documentation to include examples and tests

* 1.0.0 First attempt to submit to CRAN

* 0.4 First version of the vignette for logitexponetial (@johnaponte)

* 0.3 Inclusion of the bayesian model (@johnaponte)

* 0.2  Logitexponential model and associated functions (@johnaponte)

* 0.1  Creation and documentation of synthetic data (@johnaponte) 
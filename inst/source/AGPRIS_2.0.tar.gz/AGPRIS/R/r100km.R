#' Cropland grid of Italy (100km x 100km squares)
#'
#' SpatialPolygonsDataFrame object with croplands of Italy approximated with 100km x 100km squared polygons. It is based on croplands data contained in the Corine Land Cover 2012 raster map.
#'
#' @format SpatialPolygonsDataFrame object
#' @source \url{https://land.copernicus.eu/pan-european/corine-land-cover/clc-2012}
"r100km"
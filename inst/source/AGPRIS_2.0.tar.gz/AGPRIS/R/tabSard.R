#' Neighbors of NUTS3 of Sardinia
#'
#' A table containing the link of NUTS3 in Sardinia with NUTS3 of mainland Italy 
#'
#' @format A data frame with the links
#' 
"tabSard"
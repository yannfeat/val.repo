### aimsir17 Version 0.0.1
This is the first release of this data package containing Irish Weather Observing Stations Hourly Records for 2017.

- Added copyright information on 28/11/2019, referencing data sources as Met Eireann.


### aimsir17 Version 0.0.2
This is the second release of this data package containing Irish Weather Observing Stations Hourly Records for 2017. New data has been added relating to energy demand and generation from the Irish Grid for 2017. This data can be joined with the existiong weather data.

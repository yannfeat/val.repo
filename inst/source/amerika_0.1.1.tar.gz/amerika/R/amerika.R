#' @title amerika
#' @name amerika
#' @docType package
#' @details American politics-inspired color palettes
#' @description American politics-inspired color palettes
NULL

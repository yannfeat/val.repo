#aaa.R

env = new.env()
env$cust_local_path = NULL

library(testthat)
library(adklakedata)
Sys.setenv(R_TESTS="")
test_check('adklakedata')

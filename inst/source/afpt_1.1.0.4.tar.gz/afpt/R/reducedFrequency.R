reducedFrequency <- function(wingSpan,frequency,speed) 2*pi*frequency*wingSpan/speed

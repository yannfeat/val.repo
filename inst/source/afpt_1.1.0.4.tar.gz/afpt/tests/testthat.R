library(testthat)
library(afpt)

test_check("afpt")

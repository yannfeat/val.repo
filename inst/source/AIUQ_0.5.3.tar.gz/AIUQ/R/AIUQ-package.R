#' @importFrom stats rnorm runif qnorm optim toeplitz
#' @importFrom methods setClass new show
#' @importFrom graphics lines polygon legend
#' @importFrom plot3D image2D
#' @importFrom grDevices grey
NULL
#> NULL
#' @keywords internal
"_PACKAGE"




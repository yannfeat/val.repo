# set.seed(0)
accrual.data<-round(rexp(300,1/(365.25*3/300)))

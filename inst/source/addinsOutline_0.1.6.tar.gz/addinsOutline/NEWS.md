# NEWS


## Version 0.1.6 (initial release version)

* Added a `NEWS.md` file to track changes to the package.

<!-- # - Changes  -->
<!-- # - Bug fixes  -->
<!-- # - New features  -->

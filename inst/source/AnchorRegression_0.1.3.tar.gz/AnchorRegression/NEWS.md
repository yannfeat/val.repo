# AnchorRegression 0.1.0

* Initial implementation according to https://github.com/rothenhaeusler/anchor-regression

# AnchorRegression 0.1.1

* Initial implementation of anchor_stability with naive and post-selection decision

# AnchorRegression 0.1.2

* Initial implementation of weighted_anchor_regression and prediction functionality

# AnchorRegression 0.1.3

* Initial implementation of gam based anchor regression and prediction functionality

library(testthat)
library(AnchorRegression)

test_check("AnchorRegression")

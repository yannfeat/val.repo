library(testthat)
library(shinytest2)
library(activAnalyzer)

test_check("activAnalyzer")

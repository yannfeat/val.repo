# Code to avoid "no visible binding" messages.
english <- temp <- NULL
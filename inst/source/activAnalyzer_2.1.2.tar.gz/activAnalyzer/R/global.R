# Set the initial number of sessions
users <- shiny::reactiveValues(count = 0)


AENo <- AEYes <- count <- AE_NAME <- DRUG_TYPE <- Freq <- GROUP_NAME <- NULL
YES <- ID <- OR <- Ratio <- n_AE <- p_value <- qval <- isRatio0 <- sig <- NULL
NO <- miss <- OR_p <- N_M <- hit <- BETA <- `95Lower` <- `95Upper` <- NULL
ES <- group <- GROUP_SIZE <- Nr <- `se(logOR)`<- NULL

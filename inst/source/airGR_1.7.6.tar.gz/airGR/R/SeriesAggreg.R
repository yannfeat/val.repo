SeriesAggreg <- function(x, Format, ...) {
  UseMethod("SeriesAggreg")
}

library(testthat)
library(airGR)

test_check("airGR")

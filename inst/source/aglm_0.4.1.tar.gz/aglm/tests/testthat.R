library(testthat)
library(aglm)

test_check("aglm")

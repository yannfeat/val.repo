# aglm 0.4.1
- Fixed some notes on CRAN checks (without feature changes).

# aglm 0.4.0
- Updated all documents and examples.
- Published in [CRAN](https://cran.r-project.org/package=aglm).

# aglm 0.3.2
- Fixed to use `R` 4.0 and `glmnet` 4.0.

# agfh 0.2.1

* Response to feedback: restores user's graphical parameters at end of vignette.

# agfh 0.2.0

* First submission to CRAN.

# agfh 0.1.0

* Initial development.


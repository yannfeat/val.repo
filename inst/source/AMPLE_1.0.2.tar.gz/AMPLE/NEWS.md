# AMPLE 1.0.1

* Moved AMPLE to a new Git repository because it was getting messy in there. It's now at https://github.com/PacificCommunity/ofp-sam-ample.

* SPC logo now dynamically resizes with sidebar width.

* Fixed comments showing on introduction pages.

# AMPLE 1.0.0

* Complete rewrite of package to make use of R6 classes.

* Includes three Shiny apps in the package (*Introduction to HCRs*, *Measuring performance* and *Comparing performance*) launched using the functions *intro_hcr()*, *measuring_performance()* and *comparing_performance()*. Previous version of AMPLE only included base code for the apps, the code for which was hosted elsewhere.

* Review and rewrite of app tutorials, now included as package vignettes.
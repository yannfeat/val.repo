library(testthat)
library(AMPLE)

test_check("AMPLE")

library(testthat)
library(and)

test_check("and")

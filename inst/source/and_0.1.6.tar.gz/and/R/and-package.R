#' @keywords internal
#' @aliases and-package
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL

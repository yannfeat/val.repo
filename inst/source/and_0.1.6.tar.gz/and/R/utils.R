tag <- function(...) {
  return("")
}

release_questions <- function() "Did you run `urlchecker::url_check()`?" #nocov

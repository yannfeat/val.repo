#' Example Data 2
#'
#' Simulated dataset from Meyer et al. (2022) https://doi.org/10.1002/pst.2194. 
#'
#' @source 
#' https://github.com/el-meyer/airship/blob/master/data/ExampleDataNASH.csv
"ExampleData2"

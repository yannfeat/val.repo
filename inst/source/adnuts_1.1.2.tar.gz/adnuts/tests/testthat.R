library(testthat)
library(adnuts)

test_check("adnuts")

#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`


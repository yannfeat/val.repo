# Suppress R CMD check note
#' @importFrom memoise memoise
NULL

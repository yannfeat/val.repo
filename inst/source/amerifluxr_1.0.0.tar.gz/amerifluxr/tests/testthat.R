testthat::test_check("amerifluxr")

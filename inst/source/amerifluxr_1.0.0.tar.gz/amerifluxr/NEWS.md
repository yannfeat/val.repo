# amerifluxr 1.0.0

* major version
* first release after user testing

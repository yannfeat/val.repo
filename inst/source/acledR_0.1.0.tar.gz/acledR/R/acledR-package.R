#' @keywords internal
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL


utils::globalVariables(c("inter1", "assoc_actor_1", "inter2", "assoc_actor_2",
                         "actor", "type_of_actor", "inter_type", "assoc_actor",
                         "type_of_assoc_actor", "event_id_cnty", "admin3", "actor1", "actor2", "inter",
                         "country", "avg_month_bin", "avg_daily_bin", "n_days"))

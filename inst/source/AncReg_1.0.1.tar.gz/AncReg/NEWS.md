# AncReg 1.0.1

* Initial CRAN submission.

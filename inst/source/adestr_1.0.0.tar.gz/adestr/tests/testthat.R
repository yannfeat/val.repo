library(testthat)
library(adestr)
test_check("adestr")

# adestr 1.0.0

* Adding in all the test cases and improvements to the documentation that
were developed collaboratively. Also preparing new CRAN release.

# adestr 0.5.2

* Preparing new CRAN release: adoptr back on CRAN, adding the
collaborative produced test cases and vignettes

# adestr 0.5.1

* Replaced raster graphics in vignettes with vector graphics.

# adestr 0.5.0

* First CRAN submission.

# adestr 0.0.1

* Added a `NEWS.md` file to track changes to the package.

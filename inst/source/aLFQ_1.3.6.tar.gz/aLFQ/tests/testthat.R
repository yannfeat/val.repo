library(testthat)
library(aLFQ)


test_check("aLFQ")

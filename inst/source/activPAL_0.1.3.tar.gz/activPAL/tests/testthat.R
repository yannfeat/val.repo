library(testthat)
library(activPAL)

test_check("activPAL")

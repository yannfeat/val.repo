globalVariables(c("int_pairs", "quant_data_all", "cols_with_reference_data", "samplesGroupA", "samplesGroupB", "int_pairs"))

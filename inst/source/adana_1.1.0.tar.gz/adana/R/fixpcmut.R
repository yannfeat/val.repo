# Static crossover and mutation rate
fixpcmut = function(cxpc, mutpm, ...){
  return(list(pc=cxpc, pm=mutpm))
}
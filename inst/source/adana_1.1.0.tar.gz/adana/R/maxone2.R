# MAXONE fitness function 3
maxone2 = function(x, ...) apply(x, 1, sum)
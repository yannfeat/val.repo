# MINONE fitness function 
minone = function(x, ...) (-1*maxone(x))
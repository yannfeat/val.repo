# Delete all replacement
grdelall = function(parpop, offpop){
  parpop = offpop
  return(parpop)
}
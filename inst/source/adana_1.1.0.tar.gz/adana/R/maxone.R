# MAXONE fitness function 2
maxone = function(x, ...) sum(x==1)
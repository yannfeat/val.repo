library(testthat)
library(airGRdatasets)


test_check("airGRdatasets")

utils::globalVariables(c("value", "criteria","new"))

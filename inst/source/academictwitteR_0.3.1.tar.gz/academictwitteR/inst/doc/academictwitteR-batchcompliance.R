## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- eval = FALSE------------------------------------------------------------
#  jobid <- create_compliance_job(x = "tweet_ids.txt",
#                                 type = "tweets")
#  jobid

## ---- eval = FALSE------------------------------------------------------------
#  list_compliance_jobs()

## ---- eval = FALSE------------------------------------------------------------
#  get_compliance_result(id = "1460077048991555585")


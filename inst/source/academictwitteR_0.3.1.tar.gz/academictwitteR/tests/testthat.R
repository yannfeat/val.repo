library(testthat)
library(academictwitteR)

test_check("academictwitteR")
